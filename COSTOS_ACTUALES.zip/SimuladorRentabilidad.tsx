import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { supabase } from "../lib/supabase"
import {
  obtenerDevolucionesDb,
  type DevolucionListadoDb,
} from "../repositories/devolucionRepository"
import {
  obtenerFacturasDb,
  type FacturaDetalleDb,
} from "../repositories/facturasRepository"
import {
  obtenerNominaMensualAreaDb,
  type NominaMensualAreaDb,
} from "../repositories/nominaRepository"
import {
  obtenerPromocionesDb,
  type PromocionDb,
} from "../repositories/promocionesRepository"
import {
  obtenerReglasDistribucionDb,
  REGLAS_DISTRIBUCION_PREDETERMINADAS,
  type BaseDistribucion,
  type ReglaDistribucionDb,
} from "../repositories/rentabilidadRepository"
import {
  obtenerVentasDiariasRangoDb,
  type VentaDiariaDb,
} from "../repositories/ventasRepository"

type Cliente = {
  id: string
  nombre: string
}

type Producto = {
  id: string
  codigo: string
  nombre: string
  corto: string
}

type ClienteProducto = {
  cliente_id: string
  producto_id: string
  precio: number | null
}

type CostoProducto = {
  producto_id: string
  producto_codigo: string
  batch_calculado_kg: number | null
  rendimiento_unidades: number | null
  costo_materia_prima_unidad: number | null
  costo_empaque_unidad: number | null
  costo_materiales_unidad: number | null
  items_sin_costo: number
}

type FilaRentabilidad = {
  key: string
  clienteId: string
  cliente: string
  productoId: string
  codigo: string
  sku: string
  unidades: number
  unidadesDevueltas: number
  ventaFacturada: number
  descuentos: number
  devoluciones: number
  ventasNetas: number
  kgEquivalente: number
  costoMateriaPrimaUnitario: number | null
  costoEmpaqueUnitario: number | null
  costoMaterialesUnitario: number | null
  costoMateriales: number | null
  manoObraDirecta: number
  transporte: number
  gastoClienteDirecto: number
  gastoGeneralAsignado: number
  margenBruto: number | null
  margenBrutoPorcentaje: number | null
  contribucion: number | null
  ebitda: number | null
  margenEbitda: number | null
  completo: boolean
}

type ResumenSku = {
  id: string
  codigo: string
  nombre: string
  unidades: number
  unidadesDevueltas: number
  ventaFacturada: number
  descuentos: number
  devoluciones: number
  ventasNetas: number
  costoMateriales: number | null
  manoObraDirecta: number
  margenBruto: number | null
  margenBrutoPorcentaje: number | null
  completo: boolean
}

type ResumenCliente = {
  id: string
  nombre: string
  unidades: number
  ventasNetas: number
  transporte: number
  gastoClienteDirecto: number
  gastoGeneralAsignado: number
  gastosCliente: number
  gastosPorcentaje: number
  ebitda: number | null
  margenEbitda: number | null
  completo: boolean
}

type EscenarioComparacion = {
  id: string
  etiqueta: string
  periodo: string
  cliente: string
  sku: string
  codigo: string
  precio: number
  unidades: number
  devolucionPorcentaje: number
  descuentoPorcentaje: number
  descuentoMaximo: number
  objetivo: number
  ventaNeta: number
  margenBrutoPorcentaje: number
  ebitda: number
  margenEbitdaPorcentaje: number
  cumple: boolean
}

function fechaIsoLocal(fecha = new Date()) {
  const anio = fecha.getFullYear()
  const mes = String(fecha.getMonth() + 1).padStart(2, "0")
  const dia = String(fecha.getDate()).padStart(2, "0")
  return `${anio}-${mes}-${dia}`
}

function rangoMes(mes: string) {
  const [anio, numeroMes] = mes.split("-").map(Number)
  const ultimo = new Date(anio, numeroMes, 0).getDate()
  return {
    desde: `${mes}-01`,
    hasta: `${mes}-${String(ultimo).padStart(2, "0")}`,
  }
}

function sumarDias(fechaIso: string, dias: number) {
  const fecha = new Date(`${fechaIso}T12:00:00`)
  fecha.setDate(fecha.getDate() + dias)
  return fechaIsoLocal(fecha)
}

function inicioSemana(fechaIso: string) {
  const fecha = new Date(`${fechaIso}T12:00:00`)
  const dia = fecha.getDay()
  fecha.setDate(fecha.getDate() - (dia === 0 ? 6 : dia - 1))
  return fechaIsoLocal(fecha)
}

function normalizar(valor: string) {
  return valor
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .replace(/\s+/g, " ")
}

function claveCliente(nombre: string) {
  const texto = normalizar(nombre)
  if (
    texto.includes("FAVORITA") ||
    texto.includes("SUPERMAXI") ||
    texto.includes("MEGAMAXI")
  ) return "CORPORACION FAVORITA"
  if (texto.includes("SANTAMARIA")) return "MEGA SANTAMARIA"
  if (
    texto.includes("EL ROSADO") ||
    texto.includes("MI COMISARIATO") ||
    texto.includes("COMISARIATO")
  ) return "CORPORACION EL ROSADO"
  if (texto.includes("TUTI")) return "TUTI"
  return texto
    .replace(/\bC A\b/g, "")
    .replace(/\bCIA LTDA\b/g, "")
    .replace(/\s+/g, " ")
    .trim()
}

function dinero(valor: number) {
  return new Intl.NumberFormat("es-EC", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(valor) ? valor : 0)
}

function numero(valor: number, decimales = 0) {
  return new Intl.NumberFormat("es-EC", {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimales,
  }).format(Number.isFinite(valor) ? valor : 0)
}

function porcentaje(valor: number | null) {
  return valor === null || !Number.isFinite(valor)
    ? "—"
    : `${valor.toFixed(1)}%`
}

function valorPositivo(valor: string, respaldo = 0) {
  const numeroValor = Number(valor)
  return Number.isFinite(numeroValor) && numeroValor >= 0
    ? numeroValor
    : respaldo
}

export default function SimuladorRentabilidad() {
  const mesActual = fechaIsoLocal().slice(0, 7)
  const [mes, setMes] = useState(mesActual)
  const [vista, setVista] = useState<"SKU" | "CLIENTE" | "SIMULADOR">(
    "SKU",
  )
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [productos, setProductos] = useState<Producto[]>([])
  const [relaciones, setRelaciones] = useState<ClienteProducto[]>([])
  const [costos, setCostos] = useState<CostoProducto[]>([])
  const [ventas, setVentas] = useState<VentaDiariaDb[]>([])
  const [devoluciones, setDevoluciones] = useState<DevolucionListadoDb[]>([])
  const [facturas, setFacturas] = useState<FacturaDetalleDb[]>([])
  const [nomina, setNomina] = useState<NominaMensualAreaDb[]>([])
  const [promociones, setPromociones] = useState<PromocionDb[]>([])
  const [reglas, setReglas] = useState<ReglaDistribucionDb[]>(
    REGLAS_DISTRIBUCION_PREDETERMINADAS,
  )
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState("")
  const [advertencias, setAdvertencias] = useState<string[]>([])
  const solicitudRef = useRef(0)

  const [clienteSimulador, setClienteSimulador] = useState("")
  const [productoSimulador, setProductoSimulador] = useState("")
  const [precioSimulador, setPrecioSimulador] = useState("")
  const [unidadesSimulador, setUnidadesSimulador] = useState("1000")
  const [devolucionSimulador, setDevolucionSimulador] = useState("0")
  const [descuentoSimulador, setDescuentoSimulador] = useState("0")
  const [margenObjetivo, setMargenObjetivo] = useState("10")
  const [escenarios, setEscenarios] = useState<EscenarioComparacion[]>([])
  const [mensajeComparacion, setMensajeComparacion] = useState("")
  const numeroEscenarioRef = useRef(1)

  const rango = useMemo(() => rangoMes(mes), [mes])

  const cargarDatos = useCallback(async () => {
    const solicitud = solicitudRef.current + 1
    solicitudRef.current = solicitud
    setCargando(true)
    setError("")
    setAdvertencias([])

    const avisos: string[] = []
    const opcional = async <T,>(
      promesa: Promise<T>,
      respaldo: T,
      etiqueta: string,
    ) => {
      try {
        return await promesa
      } catch {
        avisos.push(etiqueta)
        return respaldo
      }
    }

    try {
      const [
        clientesRes,
        productosRes,
        relacionesRes,
        costosRes,
        ventasDb,
        devolucionesDb,
        facturasDb,
        nominaDb,
        promocionesDb,
        reglasDb,
      ] = await Promise.all([
        supabase
          .from("clientes")
          .select("id,nombre")
          .eq("activo", true)
          .order("nombre"),
        supabase
          .from("productos")
          .select("id,codigo,nombre,corto")
          .eq("activo", true)
          .order("corto"),
        supabase
          .from("cliente_productos")
          .select("cliente_id,producto_id,precio")
          .eq("activo", true),
        supabase
          .from("fm_vw_productos_costo_completo")
          .select(
            "producto_id,producto_codigo,batch_calculado_kg,rendimiento_unidades,costo_materia_prima_unidad,costo_empaque_unidad,costo_materiales_unidad,items_sin_costo",
          ),
        obtenerVentasDiariasRangoDb(rango.desde, rango.hasta),
        obtenerDevolucionesDb(
          rango.desde,
          sumarDias(rango.hasta, 60),
        ),
        opcional(obtenerFacturasDb(), [], "facturas y gastos"),
        opcional(obtenerNominaMensualAreaDb(), [], "nómina"),
        opcional(obtenerPromocionesDb(), [], "promociones"),
        opcional(
          obtenerReglasDistribucionDb(),
          REGLAS_DISTRIBUCION_PREDETERMINADAS,
          "reglas de distribución",
        ),
      ])

      if (clientesRes.error) throw clientesRes.error
      if (productosRes.error) throw productosRes.error
      if (relacionesRes.error) throw relacionesRes.error
      if (costosRes.error) throw costosRes.error
      if (solicitud !== solicitudRef.current) return

      setClientes((clientesRes.data ?? []) as Cliente[])
      setProductos((productosRes.data ?? []) as Producto[])
      setRelaciones((relacionesRes.data ?? []) as ClienteProducto[])
      setCostos((costosRes.data ?? []) as CostoProducto[])
      setVentas(ventasDb)
      setDevoluciones(devolucionesDb)
      setFacturas(facturasDb)
      setNomina(nominaDb)
      setPromociones(promocionesDb)
      setReglas(reglasDb)
      setAdvertencias(avisos)
    } catch (err) {
      if (solicitud !== solicitudRef.current) return
      setError(
        err instanceof Error
          ? err.message
          : "No se pudo calcular la rentabilidad.",
      )
    } finally {
      if (solicitud === solicitudRef.current) {
        setCargando(false)
      }
    }
  }, [rango.desde, rango.hasta])

  useEffect(() => {
    void cargarDatos()
  }, [cargarDatos])

  const calculo = useMemo(() => {
    type Movimiento = Omit<
      FilaRentabilidad,
      | "ventasNetas"
      | "kgEquivalente"
      | "costoMateriaPrimaUnitario"
      | "costoEmpaqueUnitario"
      | "costoMaterialesUnitario"
      | "costoMateriales"
      | "manoObraDirecta"
      | "transporte"
      | "gastoClienteDirecto"
      | "gastoGeneralAsignado"
      | "margenBruto"
      | "margenBrutoPorcentaje"
      | "contribucion"
      | "ebitda"
      | "margenEbitda"
      | "completo"
    >
    type CampoAsignado =
      | "manoObraDirecta"
      | "transporte"
      | "gastoClienteDirecto"
      | "gastoGeneralAsignado"

    const clientesId = new Map(clientes.map((item) => [item.id, item]))
    const clientesClave = new Map(
      clientes.map((item) => [claveCliente(item.nombre), item]),
    )
    const productosId = new Map(productos.map((item) => [item.id, item]))
    const productosCodigo = new Map(
      productos.map((item) => [normalizar(item.codigo), item]),
    )
    const precios = new Map(
      relaciones.map((item) => [
        `${item.cliente_id}|${item.producto_id}`,
        item.precio == null ? null : Number(item.precio),
      ]),
    )
    const costosId = new Map(
      costos.map((item) => [item.producto_id, item]),
    )
    const costosCodigo = new Map(
      costos.map((item) => [normalizar(item.producto_codigo), item]),
    )
    const reglasMapa = new Map(
      reglas.map((item) => [item.codigo, item.base_distribucion]),
    )
    const baseRegla = (codigo: string, respaldo: BaseDistribucion) =>
      reglasMapa.get(codigo) ?? respaldo

    const resolverCliente = (id: string | null, nombre: string) => {
      if (id && clientesId.has(id)) return clientesId.get(id)!
      return clientesClave.get(claveCliente(nombre)) ?? {
        id: `CLIENTE:${claveCliente(nombre)}`,
        nombre,
      }
    }
    const resolverProducto = (id: string | null, codigo: string, nombre: string) => {
      if (id && productosId.has(id)) return productosId.get(id)!
      return productosCodigo.get(normalizar(codigo)) ?? {
        id: `SKU:${normalizar(codigo)}`,
        codigo,
        corto: nombre || codigo,
        nombre: nombre || codigo,
      }
    }

    const promocionesPorClave = new Map<
      string,
      Array<{
        desde: string
        hasta: string
        tipo: "PORCENTAJE" | "VALOR_UNIDAD"
        valor: number
      }>
    >()
    promociones
      .filter((promocion) => promocion.activo)
      .forEach((promocion) => {
        promocion.productos.forEach((producto) => {
          const key = `${promocion.cliente_id}|${producto.producto_id}`
          const lista = promocionesPorClave.get(key) ?? []
          lista.push({
            desde: promocion.fecha_inicio,
            hasta: promocion.fecha_fin,
            tipo: producto.tipo_descuento,
            valor: Number(producto.valor_descuento),
          })
          promocionesPorClave.set(key, lista)
        })
      })

    const movimientos = new Map<string, Movimiento>()
    const obtenerMovimiento = (
      cliente: Cliente,
      producto: Producto,
    ) => {
      const key = `${cliente.id}|${producto.id}`
      const existente = movimientos.get(key)
      if (existente) return existente
      const nuevo: Movimiento = {
        key,
        clienteId: cliente.id,
        cliente: cliente.nombre,
        productoId: producto.id,
        codigo: producto.codigo,
        sku: producto.corto || producto.nombre,
        unidades: 0,
        unidadesDevueltas: 0,
        ventaFacturada: 0,
        descuentos: 0,
        devoluciones: 0,
      }
      movimientos.set(key, nuevo)
      return nuevo
    }

    ventas.forEach((venta) => {
      const cliente = resolverCliente(
        venta.cliente_id,
        venta.cliente_nombre,
      )
      const producto = resolverProducto(
        venta.producto_id,
        venta.sku,
        venta.producto_nombre,
      )
      const movimiento = obtenerMovimiento(cliente, producto)
      const unidades = Number(venta.cantidad ?? 0)
      const valor = Number(venta.total_sin_impuestos ?? 0)
      movimiento.unidades += unidades
      movimiento.ventaFacturada += valor

      const descuentosVenta = (
        promocionesPorClave.get(movimiento.key) ?? []
      )
        .filter(
          (promocion) =>
            venta.fecha_emision >= promocion.desde &&
            venta.fecha_emision <= promocion.hasta,
        )
        .reduce(
          (total, promocion) =>
            total +
            (promocion.tipo === "PORCENTAJE"
              ? (valor * promocion.valor) / 100
              : unidades * promocion.valor),
          0,
        )
      movimiento.descuentos += Math.min(
        Math.max(0, descuentosVenta),
        Math.max(0, valor),
      )
    })

    const semanaDesde = inicioSemana(rango.desde)
    const semanaHasta = inicioSemana(rango.hasta)
    devoluciones.forEach((devolucion) => {
      if (!devolucion.cliente) return
      const cliente = resolverCliente(
        devolucion.cliente.id,
        devolucion.cliente.nombre,
      )
      devolucion.detalles.forEach((detalle) => {
        if (
          !detalle.producto ||
          detalle.semana_origen_inicio < semanaDesde ||
          detalle.semana_origen_inicio > semanaHasta
        ) return
        const producto = resolverProducto(
          detalle.producto_id,
          detalle.producto.codigo,
          detalle.producto.corto,
        )
        const movimiento = obtenerMovimiento(cliente, producto)
        const unidades = Number(detalle.unidades ?? 0)
        const precioDocumento =
          detalle.precio_unitario_documento == null
            ? null
            : Number(detalle.precio_unitario_documento)
        const precioConfigurado = precios.get(movimiento.key) ?? null
        movimiento.unidadesDevueltas += unidades
        movimiento.devoluciones +=
          detalle.valor_total_documento == null
            ? unidades * Number(precioDocumento ?? precioConfigurado ?? 0)
            : Number(detalle.valor_total_documento)
      })
    })

    const filas: FilaRentabilidad[] = Array.from(movimientos.values()).map(
      (movimiento) => {
        const costo =
          costosId.get(movimiento.productoId) ??
          costosCodigo.get(normalizar(movimiento.codigo))
        const costoMateriaPrimaUnitario =
          costo?.costo_materia_prima_unidad == null
            ? null
            : Number(costo.costo_materia_prima_unidad)
        const costoEmpaqueUnitario =
          costo?.costo_empaque_unidad == null
            ? null
            : Number(costo.costo_empaque_unidad)
        const costoMaterialesUnitario =
          costo?.costo_materiales_unidad == null
            ? null
            : Number(costo.costo_materiales_unidad)
        const rendimiento = Number(costo?.rendimiento_unidades ?? 0)
        const kgUnitario =
          rendimiento > 0
            ? Number(costo?.batch_calculado_kg ?? 0) / rendimiento
            : 0
        const completo =
          costoMaterialesUnitario !== null &&
          Number(costo?.items_sin_costo ?? 0) === 0
        const ventasNetas =
          movimiento.ventaFacturada -
          movimiento.descuentos -
          movimiento.devoluciones
        return {
          ...movimiento,
          ventasNetas,
          kgEquivalente: movimiento.unidades * kgUnitario,
          costoMateriaPrimaUnitario,
          costoEmpaqueUnitario,
          costoMaterialesUnitario,
          costoMateriales:
            costoMaterialesUnitario === null
              ? null
              : movimiento.unidades * costoMaterialesUnitario,
          manoObraDirecta: 0,
          transporte: 0,
          gastoClienteDirecto: 0,
          gastoGeneralAsignado: 0,
          margenBruto: null,
          margenBrutoPorcentaje: null,
          contribucion: null,
          ebitda: null,
          margenEbitda: null,
          completo,
        }
      },
    )

    let costosSinAsignar = 0
    const valorBase = (fila: FilaRentabilidad, base: BaseDistribucion) => {
      if (base === "UNIDADES") return Math.max(0, fila.unidades)
      if (base === "KG_EQUIVALENTE") return Math.max(0, fila.kgEquivalente)
      return Math.max(0, fila.ventasNetas)
    }
    const asignar = (
      monto: number,
      base: BaseDistribucion,
      campo: CampoAsignado,
      clienteId?: string | null,
      excluirClienteIds?: Set<string>,
    ) => {
      if (!Number.isFinite(monto) || monto === 0) return
      const candidatas = clienteId
        ? filas.filter((fila) => fila.clienteId === clienteId)
        : excluirClienteIds?.size
          ? filas.filter((fila) => !excluirClienteIds.has(fila.clienteId))
          : filas
      let baseAplicada = base
      let totalBase = candidatas.reduce(
        (total, fila) => total + valorBase(fila, baseAplicada),
        0,
      )
      if (totalBase <= 0 && baseAplicada !== "VENTAS_NETAS") {
        baseAplicada = "VENTAS_NETAS"
        totalBase = candidatas.reduce(
          (total, fila) => total + valorBase(fila, baseAplicada),
          0,
        )
      }
      if (totalBase <= 0) {
        costosSinAsignar += monto
        return
      }
      candidatas.forEach((fila) => {
        fila[campo] +=
          (monto * valorBase(fila, baseAplicada)) / totalBase
      })
    }

    const clienteIdsTuti = new Set(
      filas
        .filter((fila) => claveCliente(fila.cliente) === "TUTI")
        .map((fila) => fila.clienteId),
    )
    const periodoNomina = `${mes}-01`
    nomina.forEach((fila) => {
      if (fila.periodo !== periodoNomina) return
      const costo = Number(fila.costo_empresa ?? 0)
      if (fila.area === "MANO_OBRA_DIRECTA") {
        asignar(
          costo,
          baseRegla("PERSONAL_PRODUCCION", "KG_EQUIVALENTE"),
          "manoObraDirecta",
        )
      } else if (fila.area === "DISTRIBUCION") {
        asignar(
          costo,
          baseRegla("TRANSPORTE", "UNIDADES"),
          "transporte",
          null,
          clienteIdsTuti,
        )
      } else {
        asignar(
          costo,
          fila.area === "MANO_OBRA_INDIRECTA"
            ? baseRegla("OPERACION", "KG_EQUIVALENTE")
            : baseRegla("PERSONAL_ESTRUCTURA", "VENTAS_NETAS"),
          "gastoGeneralAsignado",
        )
      }
    })

    const cuentasPersonal = new Set([
      "6.1.01.1.01.01",
      "6.1.01.1.01.04",
      "6.2.01.1.01.05",
      "6.1.01.1.01.06",
      "NOM-MOD",
      "NOM-MOI",
      "NOM-ADM",
      "NOM-VTA",
      "NOM-DIST",
    ])
    const cuentasTransporte = new Set([
      "6.1.01.2.13.01",
      "6.1.01.2.13.02",
    ])
    facturas.forEach((factura) => {
      const periodoFactura = factura.periodo_servicio
        ?? (factura.fecha_emision ? `${factura.fecha_emision.slice(0, 7)}-01` : null)
      if (
        factura.estado === "ANULADA" ||
        !periodoFactura ||
        periodoFactura !== `${mes}-01` ||
        !factura.impacta_ebitda ||
        cuentasPersonal.has(factura.cuenta_codigo)
      ) return
      const monto = Number(factura.subtotal ?? 0)
      const clienteIds = factura.afecta_tipo === "CLIENTE"
        ? factura.cliente_ids?.length
          ? factura.cliente_ids
          : factura.cliente_id
            ? [factura.cliente_id]
            : []
        : []
      const esTransporte = cuentasTransporte.has(
        factura.cuenta_codigo,
      )
      const base = esTransporte
        ? baseRegla("TRANSPORTE", "UNIDADES")
        : factura.grupo === "OPERACION"
          ? baseRegla("OPERACION", "KG_EQUIVALENTE")
          : baseRegla("ESTRUCTURA_GENERAL", "VENTAS_NETAS")
      if (clienteIds.length > 0) {
        const montoPorCliente = monto / clienteIds.length
        clienteIds.forEach((clienteId) => asignar(
          montoPorCliente,
          base,
          esTransporte ? "transporte" : "gastoClienteDirecto",
          clienteId,
        ))
      } else {
        asignar(
          monto,
          base,
          esTransporte ? "transporte" : "gastoGeneralAsignado",
        )
      }
    })

    filas.forEach((fila) => {
      if (!fila.completo || fila.costoMateriales === null) return
      fila.margenBruto =
        fila.ventasNetas -
        fila.costoMateriales -
        fila.manoObraDirecta
      fila.margenBrutoPorcentaje =
        fila.ventasNetas > 0
          ? (fila.margenBruto / fila.ventasNetas) * 100
          : 0
      fila.contribucion =
        fila.margenBruto -
        fila.transporte -
        fila.gastoClienteDirecto
      fila.ebitda = fila.contribucion - fila.gastoGeneralAsignado
      fila.margenEbitda =
        fila.ventasNetas > 0
          ? (fila.ebitda / fila.ventasNetas) * 100
          : 0
    })

    return { filas, costosSinAsignar, precios, costosId, costosCodigo }
  }, [
    clientes,
    productos,
    relaciones,
    costos,
    ventas,
    devoluciones,
    facturas,
    nomina,
    promociones,
    reglas,
    mes,
    rango.desde,
    rango.hasta,
  ])

  const resumenSku = useMemo(() => {
    const mapa = new Map<string, ResumenSku>()
    calculo.filas.forEach((fila) => {
      const actual = mapa.get(fila.productoId)
      if (actual) {
        actual.unidades += fila.unidades
        actual.unidadesDevueltas += fila.unidadesDevueltas
        actual.ventaFacturada += fila.ventaFacturada
        actual.descuentos += fila.descuentos
        actual.devoluciones += fila.devoluciones
        actual.ventasNetas += fila.ventasNetas
        actual.costoMateriales =
          (actual.costoMateriales ?? 0) +
          Number(fila.costoMateriales ?? 0)
        actual.manoObraDirecta += fila.manoObraDirecta
        actual.margenBruto =
          (actual.margenBruto ?? 0) +
          Number(fila.margenBruto ?? 0)
        actual.completo = actual.completo && fila.completo
      } else {
        mapa.set(fila.productoId, {
          id: fila.productoId,
          codigo: fila.codigo,
          nombre: fila.sku,
          unidades: fila.unidades,
          unidadesDevueltas: fila.unidadesDevueltas,
          ventaFacturada: fila.ventaFacturada,
          descuentos: fila.descuentos,
          devoluciones: fila.devoluciones,
          ventasNetas: fila.ventasNetas,
          costoMateriales: fila.costoMateriales,
          manoObraDirecta: fila.manoObraDirecta,
          margenBruto: fila.margenBruto,
          margenBrutoPorcentaje: null,
          completo: fila.completo,
        })
      }
    })
    return Array.from(mapa.values())
      .map((fila) => ({
        ...fila,
        costoMateriales: fila.completo
          ? fila.costoMateriales
          : null,
        margenBruto: fila.completo ? fila.margenBruto : null,
        margenBrutoPorcentaje:
          fila.completo && fila.ventasNetas > 0
            ? (Number(fila.margenBruto) / fila.ventasNetas) * 100
            : fila.completo
              ? 0
              : null,
      }))
      .sort(
        (a, b) =>
          (b.margenBrutoPorcentaje ?? -Infinity) -
          (a.margenBrutoPorcentaje ?? -Infinity),
      )
  }, [calculo.filas])

  const resumenClientes = useMemo(() => {
    const mapa = new Map<string, ResumenCliente>()
    calculo.filas.forEach((fila) => {
      const gastosCliente =
        fila.transporte +
        fila.gastoClienteDirecto +
        fila.gastoGeneralAsignado
      const actual = mapa.get(fila.clienteId)
      if (actual) {
        actual.unidades += fila.unidades
        actual.ventasNetas += fila.ventasNetas
        actual.transporte += fila.transporte
        actual.gastoClienteDirecto += fila.gastoClienteDirecto
        actual.gastoGeneralAsignado += fila.gastoGeneralAsignado
        actual.gastosCliente += gastosCliente
        actual.ebitda =
          (actual.ebitda ?? 0) + Number(fila.ebitda ?? 0)
        actual.completo = actual.completo && fila.completo
      } else {
        mapa.set(fila.clienteId, {
          id: fila.clienteId,
          nombre: fila.cliente,
          unidades: fila.unidades,
          ventasNetas: fila.ventasNetas,
          transporte: fila.transporte,
          gastoClienteDirecto: fila.gastoClienteDirecto,
          gastoGeneralAsignado: fila.gastoGeneralAsignado,
          gastosCliente,
          gastosPorcentaje: 0,
          ebitda: fila.ebitda,
          margenEbitda: null,
          completo: fila.completo,
        })
      }
    })
    return Array.from(mapa.values())
      .map((fila) => ({
        ...fila,
        ebitda: fila.completo ? fila.ebitda : null,
        gastosPorcentaje:
          fila.ventasNetas > 0
            ? (fila.gastosCliente / fila.ventasNetas) * 100
            : 0,
        margenEbitda:
          fila.completo && fila.ventasNetas > 0
            ? (Number(fila.ebitda) / fila.ventasNetas) * 100
            : fila.completo
              ? 0
              : null,
      }))
      .sort((a, b) => b.ventasNetas - a.ventasNetas)
  }, [calculo.filas])

  const clientesSimulador = useMemo(
    () =>
      clientes.filter((cliente) =>
        relaciones.some(
          (relacion) => relacion.cliente_id === cliente.id,
        ),
      ),
    [clientes, relaciones],
  )

  const productosSimulador = useMemo(() => {
    const ids = new Set(
      relaciones
        .filter(
          (relacion) =>
            relacion.cliente_id === clienteSimulador,
        )
        .map((relacion) => relacion.producto_id),
    )
    return productos.filter((producto) => ids.has(producto.id))
  }, [clienteSimulador, productos, relaciones])

  useEffect(() => {
    if (
      clientesSimulador.length > 0 &&
      !clientesSimulador.some(
        (cliente) => cliente.id === clienteSimulador,
      )
    ) {
      setClienteSimulador(clientesSimulador[0].id)
    }
  }, [clientesSimulador, clienteSimulador])

  useEffect(() => {
    if (
      productosSimulador.length > 0 &&
      !productosSimulador.some(
        (producto) => producto.id === productoSimulador,
      )
    ) {
      setProductoSimulador(productosSimulador[0].id)
    }
  }, [productosSimulador, productoSimulador])

  const filaSimulador = calculo.filas.find(
    (fila) =>
      fila.clienteId === clienteSimulador &&
      fila.productoId === productoSimulador,
  )
  const resumenClienteSimulador = resumenClientes.find(
    (fila) => fila.id === clienteSimulador,
  )
  const costoSimulador =
    calculo.costosId.get(productoSimulador) ??
    calculo.costosCodigo.get(
      normalizar(
        productos.find((item) => item.id === productoSimulador)
          ?.codigo ?? "",
      ),
    )
  const precioConfigurado = calculo.precios.get(
    `${clienteSimulador}|${productoSimulador}`,
  )

  useEffect(() => {
    if (!clienteSimulador || !productoSimulador) return
    const precioActual =
      filaSimulador && filaSimulador.unidades > 0
        ? filaSimulador.ventaFacturada / filaSimulador.unidades
        : Number(precioConfigurado ?? 0)
    const tasaDevolucion =
      filaSimulador && filaSimulador.unidades > 0
        ? (filaSimulador.unidadesDevueltas /
            filaSimulador.unidades) *
          100
        : 0
    const tasaDescuento =
      filaSimulador && filaSimulador.ventaFacturada > 0
        ? (filaSimulador.descuentos /
            filaSimulador.ventaFacturada) *
          100
        : 0
    setPrecioSimulador(precioActual ? precioActual.toFixed(4) : "")
    setUnidadesSimulador(
      String(
        Math.max(
          1,
          Math.round(filaSimulador?.unidades || 1000),
        ),
      ),
    )
    setDevolucionSimulador(tasaDevolucion.toFixed(2))
    setDescuentoSimulador(tasaDescuento.toFixed(2))
  }, [
    clienteSimulador,
    productoSimulador,
    filaSimulador,
    precioConfigurado,
  ])

  const escenario = useMemo(() => {
    const precio = valorPositivo(precioSimulador)
    const unidades = valorPositivo(unidadesSimulador)
    const tasaDevolucion = Math.min(
      100,
      valorPositivo(devolucionSimulador),
    )
    const tasaDescuento = Math.min(
      100,
      valorPositivo(descuentoSimulador),
    )
    const objetivo = Math.min(99.99, valorPositivo(margenObjetivo))
    const unidadesBase = Math.max(0, filaSimulador?.unidades ?? 0)
    const unidadesCliente = Math.max(
      0,
      resumenClienteSimulador?.unidades ?? 0,
    )
    const unidadesEmpresa = calculo.filas.reduce(
      (total, fila) => total + Math.max(0, fila.unidades),
      0,
    )
    const tasaUnitaria = (
      valorFila: number | undefined,
      valorCliente: number,
      valorEmpresa: number,
    ) => {
      if (unidadesBase > 0 && valorFila !== undefined) {
        return valorFila / unidadesBase
      }
      if (unidadesCliente > 0) return valorCliente / unidadesCliente
      return unidadesEmpresa > 0 ? valorEmpresa / unidadesEmpresa : 0
    }
    const filasCliente = calculo.filas.filter(
      (fila) => fila.clienteId === clienteSimulador,
    )
    const totalCliente = (campo: keyof FilaRentabilidad) =>
      filasCliente.reduce(
        (total, fila) => total + Number(fila[campo] ?? 0),
        0,
      )
    const totalEmpresa = (campo: keyof FilaRentabilidad) =>
      calculo.filas.reduce(
        (total, fila) => total + Number(fila[campo] ?? 0),
        0,
      )
    const materialesUnidad = Number(
      costoSimulador?.costo_materiales_unidad ?? 0,
    )
    const modUnidad = tasaUnitaria(
      filaSimulador?.manoObraDirecta,
      totalCliente("manoObraDirecta"),
      totalEmpresa("manoObraDirecta"),
    )
    const transporteUnidad = tasaUnitaria(
      filaSimulador?.transporte,
      totalCliente("transporte"),
      totalEmpresa("transporte"),
    )
    const gastoClienteUnidad = tasaUnitaria(
      filaSimulador?.gastoClienteDirecto,
      totalCliente("gastoClienteDirecto"),
      0,
    )
    const gastoGeneralUnidad = tasaUnitaria(
      filaSimulador?.gastoGeneralAsignado,
      totalCliente("gastoGeneralAsignado"),
      totalEmpresa("gastoGeneralAsignado"),
    )
    const costoTotalUnidad =
      materialesUnidad +
      modUnidad +
      transporteUnidad +
      gastoClienteUnidad +
      gastoGeneralUnidad
    const ventaBruta = precio * unidades
    const valorDescuento = (ventaBruta * tasaDescuento) / 100
    const valorDevolucion = (ventaBruta * tasaDevolucion) / 100
    const ventaNeta =
      ventaBruta - valorDescuento - valorDevolucion
    const costoTotal = costoTotalUnidad * unidades
    const margenBruto =
      ventaNeta - (materialesUnidad + modUnidad) * unidades
    const ebitda = ventaNeta - costoTotal
    const margenBrutoPorcentaje =
      ventaNeta > 0 ? (margenBruto / ventaNeta) * 100 : 0
    const margenEbitdaPorcentaje =
      ventaNeta > 0 ? (ebitda / ventaNeta) * 100 : 0
    const ventaNetaMinima =
      objetivo < 100 ? costoTotal / (1 - objetivo / 100) : Infinity
    const descuentoMaximoSinLimite =
      ventaBruta > 0
        ? ((ventaBruta - valorDevolucion - ventaNetaMinima) /
            ventaBruta) *
          100
        : 0
    const descuentoMaximo = Math.max(
      0,
      Math.min(100 - tasaDevolucion, descuentoMaximoSinLimite),
    )
    return {
      precio,
      unidades,
      tasaDevolucion,
      tasaDescuento,
      objetivo,
      materialesUnidad,
      modUnidad,
      transporteUnidad,
      gastoClienteUnidad,
      gastoGeneralUnidad,
      costoTotalUnidad,
      ventaBruta,
      valorDescuento,
      valorDevolucion,
      ventaNeta,
      costoTotal,
      margenBruto,
      margenBrutoPorcentaje,
      ebitda,
      margenEbitdaPorcentaje,
      descuentoMaximo,
      viable: descuentoMaximoSinLimite >= 0,
      dentroDelLimite:
        tasaDescuento <= descuentoMaximo + 0.0001,
      costoCompleto:
        costoSimulador != null &&
        Number(costoSimulador.items_sin_costo ?? 0) === 0,
    }
  }, [
    precioSimulador,
    unidadesSimulador,
    devolucionSimulador,
    descuentoSimulador,
    margenObjetivo,
    filaSimulador,
    resumenClienteSimulador,
    calculo.filas,
    clienteSimulador,
    costoSimulador,
  ])

  const totales = useMemo(() => {
    const completas = calculo.filas.filter((fila) => fila.completo)
    const ventasNetas = completas.reduce(
      (total, fila) => total + fila.ventasNetas,
      0,
    )
    const margenBruto = completas.reduce(
      (total, fila) => total + Number(fila.margenBruto ?? 0),
      0,
    )
    const ebitda = completas.reduce(
      (total, fila) => total + Number(fila.ebitda ?? 0),
      0,
    )
    return {
      ventasNetas,
      margenBruto,
      ebitda,
      margenBrutoPorcentaje:
        ventasNetas > 0 ? (margenBruto / ventasNetas) * 100 : 0,
      margenEbitda:
        ventasNetas > 0 ? (ebitda / ventasNetas) * 100 : 0,
      pendientes: calculo.filas.filter((fila) => !fila.completo).length,
    }
  }, [calculo.filas])

  const escenarioRecomendado = useMemo(() => {
    const cumplen = escenarios.filter((item) => item.cumple)
    const candidatas = cumplen.length > 0 ? cumplen : escenarios
    return [...candidatas].sort(
      (a, b) =>
        b.ebitda - a.ebitda ||
        b.margenEbitdaPorcentaje - a.margenEbitdaPorcentaje,
    )[0] ?? null
  }, [escenarios])

  function cargarEscenario() {
    const cliente = clientes.find(
      (item) => item.id === clienteSimulador,
    )
    const producto = productos.find(
      (item) => item.id === productoSimulador,
    )
    if (!cliente || !producto || escenario.precio <= 0 || escenario.unidades <= 0) {
      setMensajeComparacion(
        "Selecciona cliente y SKU, e ingresa precio y unidades válidos.",
      )
      return
    }
    if (!escenario.costoCompleto) {
      setMensajeComparacion(
        "No se puede cargar este escenario hasta completar el costo del SKU.",
      )
      return
    }

    const etiqueta = `E${numeroEscenarioRef.current}`
    numeroEscenarioRef.current += 1
    setEscenarios((actuales) => [
      ...actuales,
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        etiqueta,
        periodo: mes,
        cliente: cliente.nombre,
        sku: producto.corto || producto.nombre,
        codigo: producto.codigo,
        precio: escenario.precio,
        unidades: escenario.unidades,
        devolucionPorcentaje: escenario.tasaDevolucion,
        descuentoPorcentaje: escenario.tasaDescuento,
        descuentoMaximo: escenario.descuentoMaximo,
        objetivo: escenario.objetivo,
        ventaNeta: escenario.ventaNeta,
        margenBrutoPorcentaje: escenario.margenBrutoPorcentaje,
        ebitda: escenario.ebitda,
        margenEbitdaPorcentaje: escenario.margenEbitdaPorcentaje,
        cumple:
          escenario.viable &&
          escenario.dentroDelLimite &&
          escenario.margenEbitdaPorcentaje >= escenario.objetivo - 0.001,
      },
    ])
    setMensajeComparacion(`${etiqueta} cargado correctamente.`)
  }

  function eliminarEscenario(id: string) {
    setEscenarios((actuales) =>
      actuales.filter((item) => item.id !== id),
    )
    setMensajeComparacion("")
  }

  return (
    <main className="profit-sim-page">
      <style>{css}</style>
      <header className="profit-sim-header">
        <div>
          <span>RENTABILIDAD Y DECISIONES COMERCIALES</span>
          <h1>Simulador de descuentos</h1>
          <p>
            Margen bruto por SKU, gastos por cliente y descuento máximo
            para conservar la rentabilidad objetivo.
          </p>
        </div>
        <label>
          <small>Mes analizado</small>
          <input
            type="month"
            value={mes}
            onChange={(evento) => setMes(evento.target.value)}
            disabled={cargando}
          />
        </label>
      </header>

      {error && <div className="profit-sim-error">{error}</div>}
      {advertencias.length > 0 && (
        <div className="profit-sim-warning">
          Faltan datos de {advertencias.join(", ")}; los resultados que
          dependen de ellos pueden quedar incompletos.
        </div>
      )}

      <section className="profit-sim-kpis">
        <article>
          <span>Ventas netas</span>
          <strong>{cargando ? "…" : dinero(totales.ventasNetas)}</strong>
          <small>facturación − descuentos − devoluciones</small>
        </article>
        <article>
          <span>Margen bruto</span>
          <strong>
            {cargando ? "…" : porcentaje(totales.margenBrutoPorcentaje)}
          </strong>
          <small>después de materiales y mano de obra directa</small>
        </article>
        <article>
          <span>Margen EBITDA estimado</span>
          <strong>
            {cargando ? "…" : porcentaje(totales.margenEbitda)}
          </strong>
          <small>después de transporte y demás gastos</small>
        </article>
        <article>
          <span>Costos sin asignar</span>
          <strong>
            {cargando ? "…" : dinero(calculo.costosSinAsignar)}
          </strong>
          <small>{totales.pendientes} SKU con costo incompleto</small>
        </article>
      </section>

      <nav className="profit-sim-tabs">
        <button
          type="button"
          className={vista === "SKU" ? "active" : ""}
          onClick={() => setVista("SKU")}
        >
          Margen por SKU
        </button>
        <button
          type="button"
          className={vista === "CLIENTE" ? "active" : ""}
          onClick={() => setVista("CLIENTE")}
        >
          Gastos por cliente
        </button>
        <button
          type="button"
          className={vista === "SIMULADOR" ? "active" : ""}
          onClick={() => setVista("SIMULADOR")}
        >
          Simular descuento
        </button>
      </nav>

      {cargando ? (
        <section className="profit-sim-empty">Calculando rentabilidad…</section>
      ) : vista === "SKU" ? (
        <section className="profit-sim-panel">
          <header>
            <div>
              <h2>Margen bruto real por SKU</h2>
              <p>
                Incluye descuentos promocionales, devoluciones, materia
                prima, empaques y mano de obra directa.
              </p>
            </div>
          </header>
          <TablaSku filas={resumenSku} />
        </section>
      ) : vista === "CLIENTE" ? (
        <section className="profit-sim-panel">
          <header>
            <div>
              <h2>Gastos y rentabilidad por cliente</h2>
              <p>
                Separa transporte, gastos directos del cliente y gastos
                compartidos distribuidos con las reglas vigentes.
              </p>
            </div>
          </header>
          <TablaClientes filas={resumenClientes} />
        </section>
      ) : (
        <section className="profit-sim-panel simulator-panel">
          <header>
            <div>
              <h2>Escenario de descuento</h2>
              <p>
                El cálculo no modifica precios, promociones ni información
                real del sistema.
              </p>
            </div>
          </header>

          <div className="simulator-layout">
            <section className="simulator-inputs">
              <h3>Datos del escenario</h3>
              <div className="simulator-fields">
                <label>
                  <span>Cliente</span>
                  <select
                    value={clienteSimulador}
                    onChange={(evento) =>
                      setClienteSimulador(evento.target.value)
                    }
                  >
                    {clientesSimulador.map((cliente) => (
                      <option key={cliente.id} value={cliente.id}>
                        {cliente.nombre}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  <span>SKU</span>
                  <select
                    value={productoSimulador}
                    onChange={(evento) =>
                      setProductoSimulador(evento.target.value)
                    }
                  >
                    {productosSimulador.map((producto) => (
                      <option key={producto.id} value={producto.id}>
                        {producto.corto} · {producto.codigo}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  <span>Precio unitario</span>
                  <input
                    type="number"
                    min="0"
                    step="0.0001"
                    value={precioSimulador}
                    onChange={(evento) =>
                      setPrecioSimulador(evento.target.value)
                    }
                  />
                </label>
                <label>
                  <span>Unidades esperadas</span>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={unidadesSimulador}
                    onChange={(evento) =>
                      setUnidadesSimulador(evento.target.value)
                    }
                  />
                </label>
                <label>
                  <span>Devolución esperada</span>
                  <div className="input-suffix">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={devolucionSimulador}
                      onChange={(evento) =>
                        setDevolucionSimulador(evento.target.value)
                      }
                    />
                    <b>%</b>
                  </div>
                </label>
                <label>
                  <span>Descuento propuesto total</span>
                  <div className="input-suffix">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={descuentoSimulador}
                      onChange={(evento) =>
                        setDescuentoSimulador(evento.target.value)
                      }
                    />
                    <b>%</b>
                  </div>
                </label>
                <label>
                  <span>Margen EBITDA objetivo</span>
                  <div className="input-suffix">
                    <input
                      type="number"
                      min="0"
                      max="99"
                      step="0.5"
                      value={margenObjetivo}
                      onChange={(evento) =>
                        setMargenObjetivo(evento.target.value)
                      }
                    />
                    <b>%</b>
                  </div>
                </label>
              </div>
              <div className="load-scenario-actions">
                <button type="button" onClick={cargarEscenario}>
                  Cargar escenario
                </button>
                {mensajeComparacion && <small>{mensajeComparacion}</small>}
              </div>
            </section>

            <section className="simulator-result">
              <span>DESCUENTO MÁXIMO RECOMENDADO</span>
              <strong className={escenario.viable ? "good" : "bad"}>
                {escenario.costoCompleto
                  ? porcentaje(escenario.descuentoMaximo)
                  : "—"}
              </strong>
              <p>
                Para conservar un margen EBITDA de al menos{" "}
                {escenario.objetivo.toFixed(1)}%, considerando una devolución
                de {escenario.tasaDevolucion.toFixed(1)}%.
              </p>
              {!escenario.costoCompleto ? (
                <div className="decision bad">
                  Completa primero los costos de este SKU.
                </div>
              ) : escenario.dentroDelLimite && escenario.viable ? (
                <div className="decision good">
                  El descuento propuesto está dentro del límite.
                </div>
              ) : (
                <div className="decision bad">
                  El descuento propuesto reduce el margen por debajo del
                  objetivo.
                </div>
              )}
            </section>
          </div>

          <section className="scenario-kpis">
            <article>
              <span>Venta bruta</span>
              <strong>{dinero(escenario.ventaBruta)}</strong>
              <small>{numero(escenario.unidades)} unidades</small>
            </article>
            <article>
              <span>Descuento</span>
              <strong>{dinero(escenario.valorDescuento)}</strong>
              <small>{escenario.tasaDescuento.toFixed(1)}%</small>
            </article>
            <article>
              <span>Devoluciones</span>
              <strong>{dinero(escenario.valorDevolucion)}</strong>
              <small>{escenario.tasaDevolucion.toFixed(1)}%</small>
            </article>
            <article>
              <span>Venta neta</span>
              <strong>{dinero(escenario.ventaNeta)}</strong>
              <small>después de descuentos y devoluciones</small>
            </article>
            <article>
              <span>Margen bruto</span>
              <strong>{porcentaje(escenario.margenBrutoPorcentaje)}</strong>
              <small>{dinero(escenario.margenBruto)}</small>
            </article>
            <article>
              <span>Margen EBITDA</span>
              <strong>{porcentaje(escenario.margenEbitdaPorcentaje)}</strong>
              <small>{dinero(escenario.ebitda)}</small>
            </article>
          </section>

          <section className="unit-costs">
            <h3>Costo utilizado por unidad</h3>
            <div>
              <CostoUnidad
                etiqueta="Materiales y empaque"
                valor={escenario.materialesUnidad}
              />
              <CostoUnidad
                etiqueta="Mano de obra directa"
                valor={escenario.modUnidad}
              />
              <CostoUnidad
                etiqueta="Transporte"
                valor={escenario.transporteUnidad}
              />
              <CostoUnidad
                etiqueta="Gasto directo del cliente"
                valor={escenario.gastoClienteUnidad}
              />
              <CostoUnidad
                etiqueta="Gastos generales asignados"
                valor={escenario.gastoGeneralUnidad}
              />
              <CostoUnidad
                etiqueta="Costo total unitario"
                valor={escenario.costoTotalUnidad}
                total
              />
            </div>
          </section>

          {escenarios.length > 0 && (
            <section className="scenario-comparison">
              <header>
                <div>
                  <span>COMPARACIÓN DE PROPUESTAS</span>
                  <h3>Escenarios cargados</h3>
                  <p>
                    Se destaca el mayor EBITDA estimado entre los escenarios
                    que cumplen el margen objetivo.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEscenarios([])
                    setMensajeComparacion("")
                  }}
                >
                  Limpiar escenarios
                </button>
              </header>
              <TablaEscenarios
                escenarios={escenarios}
                recomendadoId={escenarioRecomendado?.id ?? null}
                onEliminar={eliminarEscenario}
              />
              <div className="comparison-chart-section">
                <h3>Comparación porcentual</h3>
                <GraficoEscenarios
                  escenarios={escenarios}
                  recomendadoId={escenarioRecomendado?.id ?? null}
                />
              </div>
            </section>
          )}
        </section>
      )}

      <footer className="profit-sim-footnote">
        Herramienta gerencial. El margen bruto resta materiales, empaques y
        mano de obra directa. El margen EBITDA añade transporte, gastos
        específicos del cliente y gastos generales distribuidos.
      </footer>
    </main>
  )
}

function TablaSku({ filas }: { filas: ResumenSku[] }) {
  if (filas.length === 0) {
    return <div className="profit-sim-empty">No existen ventas en este mes.</div>
  }
  return (
    <div className="profit-table-wrap">
      <table>
        <thead>
          <tr>
            <th>SKU</th>
            <th>Unidades</th>
            <th>Ventas brutas</th>
            <th>Descuentos</th>
            <th>Devoluciones</th>
            <th>Ventas netas</th>
            <th>Costo producto</th>
            <th>Margen bruto</th>
            <th>Margen %</th>
          </tr>
        </thead>
        <tbody>
          {filas.map((fila) => (
            <tr key={fila.id}>
              <td data-label="SKU">
                <strong>{fila.nombre}</strong>
                <small>{fila.codigo}</small>
              </td>
              <td data-label="Unidades">{numero(fila.unidades)}</td>
              <td data-label="Ventas brutas">{dinero(fila.ventaFacturada)}</td>
              <td data-label="Descuentos">{dinero(fila.descuentos)}</td>
              <td data-label="Devoluciones">
                {dinero(fila.devoluciones)}
                <small>
                  {fila.unidades > 0
                    ? `${((fila.unidadesDevueltas / fila.unidades) * 100).toFixed(1)}%`
                    : "0%"}
                </small>
              </td>
              <td data-label="Ventas netas">{dinero(fila.ventasNetas)}</td>
              <td data-label="Costo producto">
                {fila.costoMateriales === null
                  ? "—"
                  : dinero(fila.costoMateriales + fila.manoObraDirecta)}
              </td>
              <td data-label="Margen bruto">
                {fila.margenBruto === null ? "—" : dinero(fila.margenBruto)}
              </td>
              <td data-label="Margen %">
                <strong
                  className={
                    Number(fila.margenBrutoPorcentaje ?? -1) >= 0
                      ? "positive"
                      : "negative"
                  }
                >
                  {porcentaje(fila.margenBrutoPorcentaje)}
                </strong>
                {!fila.completo && <small>Costo incompleto</small>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function TablaClientes({ filas }: { filas: ResumenCliente[] }) {
  if (filas.length === 0) {
    return <div className="profit-sim-empty">No existen ventas en este mes.</div>
  }
  return (
    <div className="profit-table-wrap">
      <table>
        <thead>
          <tr>
            <th>Cliente</th>
            <th>Ventas netas</th>
            <th>Transporte</th>
            <th>Gastos directos</th>
            <th>Gastos compartidos</th>
            <th>Gasto total</th>
            <th>Gasto / ventas</th>
            <th>EBITDA estimado</th>
            <th>Margen EBITDA</th>
          </tr>
        </thead>
        <tbody>
          {filas.map((fila) => (
            <tr key={fila.id}>
              <td data-label="Cliente">
                <strong>{fila.nombre}</strong>
                <small>{numero(fila.unidades)} unidades</small>
              </td>
              <td data-label="Ventas netas">{dinero(fila.ventasNetas)}</td>
              <td data-label="Transporte">{dinero(fila.transporte)}</td>
              <td data-label="Gastos directos">
                {dinero(fila.gastoClienteDirecto)}
              </td>
              <td data-label="Gastos compartidos">
                {dinero(fila.gastoGeneralAsignado)}
              </td>
              <td data-label="Gasto total">{dinero(fila.gastosCliente)}</td>
              <td data-label="Gasto / ventas">
                {porcentaje(fila.gastosPorcentaje)}
              </td>
              <td data-label="EBITDA estimado">
                {fila.ebitda === null ? "—" : dinero(fila.ebitda)}
              </td>
              <td data-label="Margen EBITDA">
                <strong
                  className={
                    Number(fila.margenEbitda ?? -1) >= 0
                      ? "positive"
                      : "negative"
                  }
                >
                  {porcentaje(fila.margenEbitda)}
                </strong>
                {!fila.completo && <small>Costo incompleto</small>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function TablaEscenarios({
  escenarios,
  recomendadoId,
  onEliminar,
}: {
  escenarios: EscenarioComparacion[]
  recomendadoId: string | null
  onEliminar: (id: string) => void
}) {
  return (
    <div className="profit-table-wrap scenario-table-wrap">
      <table>
        <thead>
          <tr>
            <th>Escenario</th>
            <th>Cliente</th>
            <th>SKU</th>
            <th>Precio</th>
            <th>Unidades</th>
            <th>Devolución</th>
            <th>Descuento</th>
            <th>Máximo</th>
            <th>Venta neta</th>
            <th>Margen bruto</th>
            <th>EBITDA</th>
            <th>Margen EBITDA</th>
            <th>Resultado</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {escenarios.map((item) => (
            <tr
              key={item.id}
              className={item.id === recomendadoId ? "recommended-row" : ""}
            >
              <td data-label="Escenario">
                <strong>{item.etiqueta}</strong>
                <small>{item.periodo}</small>
              </td>
              <td data-label="Cliente">{item.cliente}</td>
              <td data-label="SKU">
                <strong>{item.sku}</strong>
                <small>{item.codigo}</small>
              </td>
              <td data-label="Precio">{dinero(item.precio)}</td>
              <td data-label="Unidades">{numero(item.unidades)}</td>
              <td data-label="Devolución">
                {porcentaje(item.devolucionPorcentaje)}
              </td>
              <td data-label="Descuento">
                {porcentaje(item.descuentoPorcentaje)}
              </td>
              <td data-label="Máximo">
                {porcentaje(item.descuentoMaximo)}
              </td>
              <td data-label="Venta neta">{dinero(item.ventaNeta)}</td>
              <td data-label="Margen bruto">
                {porcentaje(item.margenBrutoPorcentaje)}
              </td>
              <td data-label="EBITDA">{dinero(item.ebitda)}</td>
              <td data-label="Margen EBITDA">
                {porcentaje(item.margenEbitdaPorcentaje)}
                <small>Meta {porcentaje(item.objetivo)}</small>
              </td>
              <td data-label="Resultado">
                <span className={`scenario-status ${item.cumple ? "ok" : "no"}`}>
                  {item.id === recomendadoId
                    ? item.cumple
                      ? "Mayor EBITDA"
                      : "Mejor disponible"
                    : item.cumple
                      ? "Cumple meta"
                      : "No cumple"}
                </span>
              </td>
              <td data-label="Acción">
                <button
                  type="button"
                  className="delete-scenario"
                  onClick={() => onEliminar(item.id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function GraficoEscenarios({
  escenarios,
  recomendadoId,
}: {
  escenarios: EscenarioComparacion[]
  recomendadoId: string | null
}) {
  const ancho = Math.max(780, 120 + escenarios.length * 105)
  const alto = 340
  const izquierda = 58
  const derecha = 24
  const arriba = 28
  const abajo = 76
  const anchoGrafico = ancho - izquierda - derecha
  const altoGrafico = alto - arriba - abajo
  const minimo = Math.min(
    0,
    ...escenarios.map((item) => item.margenEbitdaPorcentaje),
  )
  const maximo = Math.max(
    10,
    ...escenarios.flatMap((item) => [
      item.descuentoPorcentaje,
      item.descuentoMaximo,
      item.margenEbitdaPorcentaje,
    ]),
  )
  const amplitud = Math.max(1, maximo - minimo)
  const y = (valor: number) =>
    arriba + ((maximo - valor) / amplitud) * altoGrafico
  const cero = y(0)
  const anchoGrupo = anchoGrafico / escenarios.length
  const anchoBarra = Math.min(22, anchoGrupo / 4.2)
  const series = [
    { key: "descuento", etiqueta: "Descuento propuesto", color: "#f7931e" },
    { key: "maximo", etiqueta: "Descuento máximo", color: "#16a34a" },
    { key: "ebitda", etiqueta: "Margen EBITDA", color: "#8f1d24" },
  ] as const
  const valorSerie = (
    item: EscenarioComparacion,
    key: (typeof series)[number]["key"],
  ) =>
    key === "descuento"
      ? item.descuentoPorcentaje
      : key === "maximo"
        ? item.descuentoMaximo
        : item.margenEbitdaPorcentaje

  return (
    <div className="comparison-chart">
      <div className="chart-legend">
        {series.map((serie) => (
          <span key={serie.key}>
            <i style={{ background: serie.color }} />
            {serie.etiqueta}
          </span>
        ))}
      </div>
      <div className="chart-scroll">
        <svg
          viewBox={`0 0 ${ancho} ${alto}`}
          style={{ minWidth: ancho }}
          role="img"
          aria-label="Comparación de descuentos y margen EBITDA por escenario"
        >
          {Array.from({ length: 6 }, (_, indice) => {
            const valor = maximo - (amplitud * indice) / 5
            const posicionY = y(valor)
            return (
              <g key={indice}>
                <line
                  x1={izquierda}
                  y1={posicionY}
                  x2={ancho - derecha}
                  y2={posicionY}
                  stroke="#e7e5e4"
                  strokeWidth="1"
                />
                <text
                  x={izquierda - 8}
                  y={posicionY + 4}
                  textAnchor="end"
                  className="chart-axis-label"
                >
                  {valor.toFixed(0)}%
                </text>
              </g>
            )
          })}
          {escenarios.map((item, indice) => {
            const centro = izquierda + anchoGrupo * (indice + 0.5)
            const inicio = centro - anchoBarra * 1.7
            return (
              <g key={item.id}>
                {item.id === recomendadoId && (
                  <rect
                    x={izquierda + anchoGrupo * indice + 4}
                    y={arriba - 10}
                    width={Math.max(0, anchoGrupo - 8)}
                    height={altoGrafico + 38}
                    rx="8"
                    fill="#fff7ed"
                  />
                )}
                {series.map((serie, serieIndice) => {
                  const valor = valorSerie(item, serie.key)
                  const posicionY = y(valor)
                  const altoBarra = Math.max(1, Math.abs(cero - posicionY))
                  return (
                    <rect
                      key={serie.key}
                      x={inicio + serieIndice * anchoBarra * 1.15}
                      y={Math.min(cero, posicionY)}
                      width={anchoBarra}
                      height={altoBarra}
                      rx="3"
                      fill={valor < 0 ? "#dc2626" : serie.color}
                    >
                      <title>
                        {item.etiqueta} · {serie.etiqueta}: {valor.toFixed(1)}%
                      </title>
                    </rect>
                  )
                })}
                <text
                  x={centro}
                  y={alto - 47}
                  textAnchor="middle"
                  className="chart-scenario-label"
                >
                  {item.etiqueta}
                </text>
                <text
                  x={centro}
                  y={alto - 30}
                  textAnchor="middle"
                  className="chart-scenario-detail"
                >
                  {item.sku.slice(0, 14)}
                </text>
                <text
                  x={centro}
                  y={alto - 14}
                  textAnchor="middle"
                  className="chart-scenario-detail"
                >
                  {item.cliente.slice(0, 16)}
                </text>
              </g>
            )
          })}
          <line
            x1={izquierda}
            y1={cero}
            x2={ancho - derecha}
            y2={cero}
            stroke="#78716c"
            strokeWidth="1.5"
          />
        </svg>
      </div>
    </div>
  )
}

function CostoUnidad({
  etiqueta,
  valor,
  total = false,
}: {
  etiqueta: string
  valor: number
  total?: boolean
}) {
  return (
    <article className={total ? "total" : ""}>
      <span>{etiqueta}</span>
      <strong>{dinero(valor)}</strong>
    </article>
  )
}

const css = `
  .profit-sim-page{max-width:1720px;margin:0 auto;padding:28px;color:#25272b;background:#f8f5f1;min-height:100vh}
  .profit-sim-header{display:flex;justify-content:space-between;align-items:flex-end;gap:22px;margin-bottom:20px}
  .profit-sim-header>div>span,.profit-sim-panel>header span,.simulator-result>span{color:#8f1d24;font-size:11px;font-weight:900;letter-spacing:1px}
  .profit-sim-header h1{margin:5px 0;font-size:34px}.profit-sim-header p,.profit-sim-panel header p{margin:0;color:#6b7280;font-size:13px}
  .profit-sim-header label{width:220px}.profit-sim-header label small{display:block;margin-bottom:6px;color:#6b7280;font-weight:800}
  .profit-sim-header input,.simulator-fields input,.simulator-fields select{width:100%;min-height:42px;box-sizing:border-box;padding:9px 11px;border:1px solid #d5d9de;border-radius:8px;background:white;color:#25272b}
  .profit-sim-error,.profit-sim-warning{margin-bottom:16px;padding:13px 15px;border-radius:9px;font-size:13px}.profit-sim-error{background:#fee2e2;color:#991b1b;border-left:5px solid #b91c1c}.profit-sim-warning{background:#fff7ed;color:#9a3412;border-left:5px solid #f7931e}
  .profit-sim-kpis,.scenario-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px;margin-bottom:18px}
  .profit-sim-kpis article,.scenario-kpis article{display:flex;flex-direction:column;gap:6px;padding:16px;border:1px solid #eee3dd;border-radius:12px;background:white;box-shadow:0 4px 14px rgba(72,42,32,.04)}
  .profit-sim-kpis span,.scenario-kpis span{color:#6b7280;font-size:11px;font-weight:800}.profit-sim-kpis strong,.scenario-kpis strong{color:#8f1d24;font-size:24px}.profit-sim-kpis small,.scenario-kpis small{color:#8e7c75;font-size:10px}
  .profit-sim-tabs{display:flex;gap:7px;width:fit-content;margin-bottom:18px;padding:5px;border-radius:10px;background:#ece8e5}
  .profit-sim-tabs button{padding:10px 15px;border:0;border-radius:8px;background:transparent;color:#6b7280;font-weight:800;cursor:pointer}.profit-sim-tabs button.active{background:#8f1d24;color:white;box-shadow:0 5px 12px rgba(143,29,36,.18)}
  .profit-sim-panel{padding:20px;border:1px solid #eee3dd;border-radius:14px;background:white;box-shadow:0 6px 20px rgba(72,42,32,.05)}
  .profit-sim-panel>header{display:flex;justify-content:space-between;gap:14px;margin-bottom:16px}.profit-sim-panel h2{margin:0 0 5px;font-size:22px}
  .profit-table-wrap{overflow:auto;border:1px solid #eceff2;border-radius:10px}.profit-table-wrap table{width:100%;border-collapse:collapse;min-width:1050px}.profit-table-wrap th{padding:10px;background:#f8f6f4;color:#6b7280;text-align:left;font-size:11px;white-space:nowrap}.profit-table-wrap td{padding:10px;border-top:1px solid #edf0f2;text-align:right;font-size:12px;white-space:nowrap}.profit-table-wrap th:first-child,.profit-table-wrap td:first-child{text-align:left}.profit-table-wrap td strong{display:block}.profit-table-wrap td small{display:block;margin-top:3px;color:#8e7c75;font-size:10px}.positive{color:#15803d}.negative{color:#b91c1c}
  .profit-sim-empty{padding:32px;border:1px dashed #d1d5db;border-radius:10px;background:white;color:#6b7280;text-align:center}
  .simulator-layout{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(290px,.8fr);gap:16px;margin-bottom:18px}.simulator-inputs,.simulator-result,.unit-costs{padding:17px;border:1px solid #eee3dd;border-radius:12px;background:#fff}.simulator-inputs h3,.unit-costs h3{margin:0 0 13px;font-size:16px}.simulator-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.simulator-fields label>span{display:block;margin-bottom:6px;color:#4b5563;font-size:11px;font-weight:800}.input-suffix{position:relative}.input-suffix input{padding-right:32px}.input-suffix b{position:absolute;right:11px;top:12px;color:#8f1d24;font-size:12px}
  .load-scenario-actions{display:flex;align-items:center;gap:12px;margin-top:15px}.load-scenario-actions button{min-height:42px;padding:0 20px;border:0;border-radius:8px;background:#8f1d24;color:white;font-weight:900;cursor:pointer;box-shadow:0 6px 14px rgba(143,29,36,.18)}.load-scenario-actions button:hover{background:#68151a}.load-scenario-actions small{color:#6b7280;font-size:11px}
  .simulator-result{display:flex;flex-direction:column;justify-content:center;text-align:center;background:linear-gradient(145deg,#fff7ed,#fff)}.simulator-result>strong{display:block;margin:8px 0;font-size:54px;line-height:1}.simulator-result>strong.good{color:#15803d}.simulator-result>strong.bad{color:#b91c1c}.simulator-result p{margin:0;color:#6b7280;font-size:12px;line-height:1.5}.decision{margin-top:14px;padding:10px;border-radius:8px;font-size:12px;font-weight:800}.decision.good{background:#dcfce7;color:#166534}.decision.bad{background:#fee2e2;color:#991b1b}
  .scenario-kpis{grid-template-columns:repeat(6,minmax(0,1fr))}.scenario-kpis strong{font-size:20px}
  .unit-costs{margin-top:4px;background:#faf9f8}.unit-costs>div{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:9px}.unit-costs article{display:flex;flex-direction:column;gap:5px;padding:10px;border-radius:8px;background:white}.unit-costs article span{color:#6b7280;font-size:10px}.unit-costs article strong{font-size:15px}.unit-costs article.total{background:#8f1d24;color:white}.unit-costs article.total span{color:#f8e8e9}
  .scenario-comparison{margin-top:20px;padding-top:20px;border-top:2px solid #eee3dd}.scenario-comparison>header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}.scenario-comparison>header span{color:#8f1d24;font-size:10px;font-weight:900;letter-spacing:1px}.scenario-comparison>header h3{margin:3px 0;font-size:19px}.scenario-comparison>header p{margin:0;color:#6b7280;font-size:11px}.scenario-comparison>header button{min-height:38px;padding:0 13px;border:1px solid #b9aaa4;border-radius:8px;background:white;color:#6b4d45;font-weight:800;cursor:pointer}.scenario-table-wrap table{min-width:1460px}.scenario-table-wrap tr.recommended-row{background:#fffaf0}.scenario-status{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:9px;font-weight:900}.scenario-status.ok{background:#dcfce7;color:#166534}.scenario-status.no{background:#fee2e2;color:#991b1b}.delete-scenario{padding:6px 9px;border:1px solid #efb5b5;border-radius:7px;background:white;color:#b91c1c;font-size:10px;font-weight:800;cursor:pointer}.comparison-chart-section{margin-top:18px;padding:16px;border:1px solid #eee3dd;border-radius:12px;background:#faf9f8}.comparison-chart-section>h3{margin:0 0 10px;font-size:16px}.comparison-chart{border-radius:9px;background:white}.chart-legend{display:flex;flex-wrap:wrap;gap:14px;padding:13px 15px 0}.chart-legend span{display:flex;align-items:center;gap:6px;color:#6b7280;font-size:10px;font-weight:800}.chart-legend i{width:10px;height:10px;border-radius:3px}.chart-scroll{overflow-x:auto}.chart-scroll svg{display:block;width:100%;height:auto}.chart-axis-label{fill:#78716c;font-size:10px}.chart-scenario-label{fill:#8f1d24;font-size:12px;font-weight:900}.chart-scenario-detail{fill:#78716c;font-size:8px}
  .profit-sim-footnote{margin-top:13px;color:#8e7c75;font-size:11px;line-height:1.5}
  @media(max-width:1100px){.profit-sim-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.scenario-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.unit-costs>div{grid-template-columns:repeat(3,minmax(0,1fr))}.simulator-layout{grid-template-columns:1fr}}
  @media(max-width:700px){.profit-sim-page{padding:12px 10px 24px}.profit-sim-header{align-items:stretch;flex-direction:column}.profit-sim-header h1{font-size:26px}.profit-sim-header label{width:100%}.profit-sim-kpis{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.profit-sim-kpis article{padding:11px}.profit-sim-kpis strong{font-size:19px}.profit-sim-tabs{display:grid;grid-template-columns:1fr;width:100%;box-sizing:border-box}.profit-sim-panel{padding:12px}.simulator-fields{grid-template-columns:1fr}.load-scenario-actions{align-items:stretch;flex-direction:column}.scenario-kpis,.unit-costs>div{grid-template-columns:repeat(2,minmax(0,1fr))}.profit-table-wrap{overflow:visible;border:0}.profit-table-wrap table,.profit-table-wrap tbody,.profit-table-wrap tr,.profit-table-wrap td{display:block;width:100%;box-sizing:border-box}.profit-table-wrap table{min-width:0}.profit-table-wrap thead{display:none}.profit-table-wrap tbody{display:grid;gap:9px}.profit-table-wrap tr{padding:9px 11px;border:1px solid #eee3dd;border-radius:10px}.profit-table-wrap td{display:grid;grid-template-columns:120px minmax(0,1fr);align-items:center;gap:8px;padding:6px 0;border:0;text-align:right;white-space:normal}.profit-table-wrap td:first-child{text-align:right}.profit-table-wrap td:before{content:attr(data-label);color:#8e7c75;text-align:left;font-size:10px;font-weight:800}.simulator-result>strong{font-size:44px}.scenario-comparison>header{flex-direction:column}.comparison-chart-section{padding:10px}}
`
