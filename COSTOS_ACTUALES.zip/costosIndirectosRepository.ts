import { supabase } from "../lib/supabase"

export type LineaResultadoImportar = {
  periodo: string
  cuenta_codigo: string
  cuenta_descripcion: string
  valor: number
}

export type ImportacionResultadosDb = {
  id: string
  archivo_nombre: string
  periodo_desde: string
  periodo_hasta: string
  meses_incluidos: number
  cuentas_incluidas: number
  registros_importados: number
  creado_en: string
}

export type ResultadoMensualDb = {
  periodo: string
  cuentas: number
  ventas_netas: number
  costo_ventas: number
  gastos_ventas: number
  gastos_administracion: number
  otros_ingresos: number
  gastos_financieros: number
  depreciacion: number
  resultado_operativo: number
  ebitda_estimado: number
  margen_ebitda_estimado: number | null
  resultado_ejercicio: number
  actualizado_en: string
}

export type RespuestaImportacionResultados = {
  importacion_id: string
  periodo_desde: string
  periodo_hasta: string
  meses_importados: number
  cuentas_importadas: number
  registros_importados: number
}

export async function obtenerImportacionesResultadosDb() {
  const { data, error } = await supabase
    .from("fin_importaciones_resultados")
    .select(`
      id,
      archivo_nombre,
      periodo_desde,
      periodo_hasta,
      meses_incluidos,
      cuentas_incluidas,
      registros_importados,
      creado_en
    `)
    .order("creado_en", { ascending: false })
    .limit(24)

  if (error) {
    throw new Error(
      `No se pudo cargar el historial de balances: ${error.message}`,
    )
  }

  return (data ?? []) as ImportacionResultadosDb[]
}

export async function obtenerResultadosMensualesDb() {
  const { data, error } = await supabase
    .from("fin_vw_resultado_mensual")
    .select("*")
    .order("periodo", { ascending: false })

  if (error) {
    throw new Error(
      `No se pudo cargar el resumen mensual: ${error.message}`,
    )
  }

  return (data ?? []) as ResultadoMensualDb[]
}

export async function importarBalanceResultadosDb(datos: {
  archivoNombre: string
  lineas: LineaResultadoImportar[]
}) {
  const { data, error } = await supabase.rpc(
    "fin_importar_balance_resultados",
    {
      p_archivo_nombre: datos.archivoNombre,
      p_lineas: datos.lineas,
    },
  )

  if (error) {
    throw new Error(
      `No se pudo guardar el balance: ${error.message}`,
    )
  }

  return data as RespuestaImportacionResultados
}
