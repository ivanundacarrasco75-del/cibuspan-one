import { useEffect, useMemo, useState } from "react"

import { supabase } from "../lib/supabase"
import {
  obtenerDetallePedidoDb,
  obtenerPedidosDb,
  type DetallePedidoConsultaDb,
  type PedidoListadoDb,
} from "../repositories/pedidoRepository"

type ComercialVentasProps = {
  cambiarPantalla: (pantalla: string) => void
}

type PedidoConDetalle = {
  pedido: PedidoListadoDb
  detalles: DetallePedidoConsultaDb[]
}

type PrecioClienteProducto = {
  cliente_id: string
  producto_id: string
  precio: number | null
}

type VentaLinea = {
  id: string
  fecha: string
  pedidoId: string
  numeroPedido: string
  clienteId: string
  cliente: string
  bodega: string
  productoId: string
  codigo: string
  sku: string
  solicitadas: number
  despachadas: number
  precioUnitario: number | null
  valor: number | null
}

type VistaVentas = "DETALLE" | "CLIENTE" | "SKU"

type GrupoVenta = {
  id: string
  nombre: string
  secundario: string
  despachos: number
  solicitadas: number
  despachadas: number
  fillRate: number
  valor: number
  lineasSinPrecio: number
}

const VINO = "#8F1D24"
const NARANJA = "#F7931E"

function fechaIsoLocal(fecha: Date) {
  const anio = fecha.getFullYear()
  const mes = String(fecha.getMonth() + 1).padStart(2, "0")
  const dia = String(fecha.getDate()).padStart(2, "0")
  return `${anio}-${mes}-${dia}`
}

function primerDiaMes(fecha: Date) {
  return `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, "0")}-01`
}

function numero(valor: number) {
  return new Intl.NumberFormat("es-EC", {
    maximumFractionDigits: 0,
  }).format(Number(valor || 0))
}

function moneda(valor: number) {
  return new Intl.NumberFormat("es-EC", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number(valor || 0))
}

function porcentaje(valor: number) {
  return `${Number(valor || 0).toFixed(1)}%`
}

function escaparCsv(valor: unknown) {
  return `"${String(valor ?? "").replaceAll('"', '""')}"`
}

export default function ComercialVentas({
  cambiarPantalla,
}: ComercialVentasProps) {
  const hoy = fechaIsoLocal(new Date())

  const [fechaDesde, setFechaDesde] = useState(primerDiaMes(new Date()))
  const [fechaHasta, setFechaHasta] = useState(hoy)
  const [pedidos, setPedidos] = useState<PedidoConDetalle[]>([])
  const [precios, setPrecios] = useState<PrecioClienteProducto[]>([])
  const [clienteFiltro, setClienteFiltro] = useState("TODOS")
  const [skuFiltro, setSkuFiltro] = useState("TODOS")
  const [busqueda, setBusqueda] = useState("")
  const [vista, setVista] = useState<VistaVentas>("DETALLE")
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState("")
  const [avisoPrecio, setAvisoPrecio] = useState("")

  useEffect(() => {
    cargarDatos()
  }, [])

  async function cargarDatos() {
    if (!fechaDesde || !fechaHasta) {
      setError("Selecciona un rango de fechas.")
      return
    }

    if (fechaDesde > fechaHasta) {
      setError("La fecha desde no puede ser posterior a la fecha hasta.")
      return
    }

    setCargando(true)
    setError("")
    setAvisoPrecio("")

    try {
      const [pedidosDb, preciosRes] = await Promise.all([
        obtenerPedidosDb(),
        supabase
          .from("cliente_productos")
          .select("cliente_id, producto_id, precio")
          .eq("activo", true),
      ])

      const despachadosPeriodo = pedidosDb.filter(
        (pedido) =>
          pedido.estado === "DESPACHADO" &&
          pedido.fecha_entrega >= fechaDesde &&
          pedido.fecha_entrega <= fechaHasta,
      )

      const pedidosConDetalle = await Promise.all(
        despachadosPeriodo.map(async (pedido) => ({
          pedido,
          detalles: await obtenerDetallePedidoDb(pedido.id),
        })),
      )

      setPedidos(pedidosConDetalle)

      if (preciosRes.error) {
        setPrecios([])
        setAvisoPrecio(
          "No se pudieron consultar los precios configurados. Las unidades siguen siendo válidas, pero la valorización no está disponible.",
        )
      } else {
        setPrecios((preciosRes.data ?? []) as PrecioClienteProducto[])
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "No se pudieron cargar las ventas.",
      )
    } finally {
      setCargando(false)
    }
  }

  const preciosMapa = useMemo(
    () =>
      new Map(
        precios.map((item) => [
          `${item.cliente_id}|${item.producto_id}`,
          item.precio === null ? null : Number(item.precio),
        ]),
      ),
    [precios],
  )

  const lineas = useMemo<VentaLinea[]>(() => {
    const resultado: VentaLinea[] = []

    pedidos.forEach(({ pedido, detalles }) => {
      detalles.forEach((detalle) => {
        const despachadas = Number(detalle.unidades_despachadas ?? 0)
        if (despachadas <= 0 || !detalle.producto) return

        const clienteId = pedido.cliente?.id ?? ""
        const precio =
          clienteId
            ? preciosMapa.get(`${clienteId}|${detalle.producto_id}`) ?? null
            : null

        resultado.push({
          id: `${pedido.id}|${detalle.id}`,
          fecha: pedido.fecha_entrega,
          pedidoId: pedido.id,
          numeroPedido: pedido.numero_pedido_cliente || pedido.id,
          clienteId,
          cliente: pedido.cliente?.nombre ?? "Cliente no identificado",
          bodega: pedido.bodega?.nombre ?? "—",
          productoId: detalle.producto_id,
          codigo: detalle.producto.codigo,
          sku: detalle.producto.corto || detalle.producto.nombre,
          solicitadas: Number(detalle.total_unidades ?? 0),
          despachadas,
          precioUnitario: precio,
          valor: precio === null ? null : despachadas * precio,
        })
      })
    })

    return resultado.sort((a, b) => {
      const fecha = b.fecha.localeCompare(a.fecha)
      if (fecha !== 0) return fecha
      return a.cliente.localeCompare(b.cliente)
    })
  }, [pedidos, preciosMapa])

  const clientes = useMemo(() => {
    const mapa = new Map<string, string>()
    lineas.forEach((linea) => {
      if (linea.clienteId) mapa.set(linea.clienteId, linea.cliente)
    })
    return Array.from(mapa, ([id, nombre]) => ({ id, nombre })).sort((a, b) =>
      a.nombre.localeCompare(b.nombre),
    )
  }, [lineas])

  const skus = useMemo(() => {
    const mapa = new Map<
      string,
      { id: string; codigo: string; nombre: string }
    >()

    lineas.forEach((linea) => {
      mapa.set(linea.productoId, {
        id: linea.productoId,
        codigo: linea.codigo,
        nombre: linea.sku,
      })
    })

    return Array.from(mapa.values()).sort((a, b) =>
      a.nombre.localeCompare(b.nombre),
    )
  }, [lineas])

  const lineasFiltradas = useMemo(() => {
    const texto = busqueda.trim().toLowerCase()

    return lineas.filter((linea) => {
      if (
        clienteFiltro !== "TODOS" &&
        linea.clienteId !== clienteFiltro
      ) {
        return false
      }

      if (
        skuFiltro !== "TODOS" &&
        linea.productoId !== skuFiltro
      ) {
        return false
      }

      if (!texto) return true

      return (
        linea.cliente.toLowerCase().includes(texto) ||
        linea.bodega.toLowerCase().includes(texto) ||
        linea.codigo.toLowerCase().includes(texto) ||
        linea.sku.toLowerCase().includes(texto) ||
        linea.numeroPedido.toLowerCase().includes(texto)
      )
    })
  }, [lineas, clienteFiltro, skuFiltro, busqueda])

  const resumen = useMemo(() => {
    const solicitadas = lineasFiltradas.reduce(
      (total, linea) => total + linea.solicitadas,
      0,
    )
    const despachadas = lineasFiltradas.reduce(
      (total, linea) => total + linea.despachadas,
      0,
    )
    const valor = lineasFiltradas.reduce(
      (total, linea) => total + Number(linea.valor ?? 0),
      0,
    )
    const lineasConPrecio = lineasFiltradas.filter(
      (linea) => linea.precioUnitario !== null,
    ).length
    const lineasSinPrecio =
      lineasFiltradas.length - lineasConPrecio
    const despachos = new Set(
      lineasFiltradas.map((linea) => linea.pedidoId),
    ).size
    const fillRate =
      solicitadas > 0 ? (despachadas / solicitadas) * 100 : 0
    const coberturaPrecio =
      lineasFiltradas.length > 0
        ? (lineasConPrecio / lineasFiltradas.length) * 100
        : 0

    return {
      solicitadas,
      despachadas,
      valor,
      lineasSinPrecio,
      despachos,
      fillRate,
      coberturaPrecio,
    }
  }, [lineasFiltradas])

  function agrupar(tipo: "CLIENTE" | "SKU") {
    const mapa = new Map<
      string,
      {
        id: string
        nombre: string
        secundario: string
        pedidos: Set<string>
        solicitadas: number
        despachadas: number
        valor: number
        lineasSinPrecio: number
      }
    >()

    lineasFiltradas.forEach((linea) => {
      const id = tipo === "CLIENTE" ? linea.clienteId : linea.productoId
      const nombre = tipo === "CLIENTE" ? linea.cliente : linea.sku
      const secundario =
        tipo === "CLIENTE" ? "Cliente" : linea.codigo

      const actual =
        mapa.get(id) ?? {
          id,
          nombre,
          secundario,
          pedidos: new Set<string>(),
          solicitadas: 0,
          despachadas: 0,
          valor: 0,
          lineasSinPrecio: 0,
        }

      actual.pedidos.add(linea.pedidoId)
      actual.solicitadas += linea.solicitadas
      actual.despachadas += linea.despachadas

      if (linea.valor === null) {
        actual.lineasSinPrecio += 1
      } else {
        actual.valor += linea.valor
      }

      mapa.set(id, actual)
    })

    return Array.from(mapa.values())
      .map<GrupoVenta>((item) => ({
        id: item.id,
        nombre: item.nombre,
        secundario: item.secundario,
        despachos: item.pedidos.size,
        solicitadas: item.solicitadas,
        despachadas: item.despachadas,
        fillRate:
          item.solicitadas > 0
            ? (item.despachadas / item.solicitadas) * 100
            : 0,
        valor: item.valor,
        lineasSinPrecio: item.lineasSinPrecio,
      }))
      .sort((a, b) => b.despachadas - a.despachadas)
  }

  const resumenClientes = useMemo(
    () => agrupar("CLIENTE"),
    [lineasFiltradas],
  )

  const resumenSku = useMemo(
    () => agrupar("SKU"),
    [lineasFiltradas],
  )

  function limpiarFiltros() {
    setClienteFiltro("TODOS")
    setSkuFiltro("TODOS")
    setBusqueda("")
  }

  function exportarCsv() {
    const encabezados = [
      "Fecha",
      "Pedido",
      "Cliente",
      "Bodega",
      "Codigo SKU",
      "SKU",
      "Unidades solicitadas",
      "Unidades despachadas",
      "Fill Rate linea",
      "Precio configurado",
      "Valor despachado",
    ]

    const filas = lineasFiltradas.map((linea) => [
      linea.fecha,
      linea.numeroPedido,
      linea.cliente,
      linea.bodega,
      linea.codigo,
      linea.sku,
      linea.solicitadas,
      linea.despachadas,
      linea.solicitadas > 0
        ? `${((linea.despachadas / linea.solicitadas) * 100).toFixed(1)}%`
        : "0.0%",
      linea.precioUnitario ?? "",
      linea.valor ?? "",
    ])

    const contenido = [encabezados, ...filas]
      .map((fila) => fila.map(escaparCsv).join(","))
      .join("\n")

    const blob = new Blob([`\uFEFF${contenido}`], {
      type: "text/csv;charset=utf-8",
    })
    const url = URL.createObjectURL(blob)
    const enlace = document.createElement("a")
    enlace.href = url
    enlace.download = `ventas-cibuspan-${fechaDesde}-${fechaHasta}.csv`
    enlace.click()
    URL.revokeObjectURL(url)
  }

  return (
    <main className="sales-page">
      <style>{css}</style>

      <header className="sales-header">
        <div>
          <span className="sales-kicker">COMERCIAL · VENTAS</span>
          <h1>Ventas</h1>
          <p>
            Pantalla oficial de movimiento comercial basado en despachos
            confirmados.
          </p>
        </div>

        <div className="sales-header-actions">
          <button type="button" className="secondary" onClick={() => window.print()}>
            Imprimir
          </button>
          <button
            type="button"
            className="secondary"
            onClick={exportarCsv}
            disabled={cargando || lineasFiltradas.length === 0}
          >
            Exportar CSV
          </button>
          <button type="button" className="primary" onClick={cargarDatos} disabled={cargando}>
            {cargando ? "Actualizando..." : "Actualizar"}
          </button>
        </div>
      </header>

      <section className="sales-source-note">
        <div>
          <strong>Fuente operativa:</strong> pedidos con estado DESPACHADO y
          unidades realmente despachadas.
        </div>
        <span>Periodo {fechaDesde} → {fechaHasta}</span>
      </section>

      {error && <div className="sales-error">{error}</div>}

      {(avisoPrecio || resumen.lineasSinPrecio > 0) && (
        <div className="sales-warning">
          <strong>Valorización:</strong>{" "}
          {avisoPrecio ||
            `${resumen.lineasSinPrecio} línea${
              resumen.lineasSinPrecio === 1 ? "" : "s"
            } no tiene${resumen.lineasSinPrecio === 1 ? "" : "n"} precio configurado. El total monetario mostrado es parcial.`}
          <br />
          <small>
            La facturación importada será la fuente monetaria definitiva cuando
            integremos ese histórico en esta misma pantalla.
          </small>
        </div>
      )}

      <section className="sales-filter-panel">
        <div className="sales-filter-grid">
          <label>
            <span>Desde</span>
            <input
              type="date"
              value={fechaDesde}
              onChange={(evento) => setFechaDesde(evento.target.value)}
            />
          </label>

          <label>
            <span>Hasta</span>
            <input
              type="date"
              value={fechaHasta}
              onChange={(evento) => setFechaHasta(evento.target.value)}
            />
          </label>

          <label>
            <span>Cliente</span>
            <select
              value={clienteFiltro}
              onChange={(evento) => setClienteFiltro(evento.target.value)}
            >
              <option value="TODOS">Todos los clientes</option>
              {clientes.map((cliente) => (
                <option key={cliente.id} value={cliente.id}>
                  {cliente.nombre}
                </option>
              ))}
            </select>
          </label>

          <label>
            <span>SKU</span>
            <select
              value={skuFiltro}
              onChange={(evento) => setSkuFiltro(evento.target.value)}
            >
              <option value="TODOS">Todos los SKU</option>
              {skus.map((sku) => (
                <option key={sku.id} value={sku.id}>
                  {sku.codigo} · {sku.nombre}
                </option>
              ))}
            </select>
          </label>

          <label className="sales-search">
            <span>Buscar</span>
            <input
              value={busqueda}
              onChange={(evento) => setBusqueda(evento.target.value)}
              placeholder="Pedido, cliente, bodega o SKU"
            />
          </label>
        </div>

        <div className="sales-filter-actions">
          <button type="button" onClick={limpiarFiltros}>
            Limpiar filtros
          </button>
          <button type="button" className="apply" onClick={cargarDatos}>
            Aplicar periodo
          </button>
        </div>
      </section>

      <section className="sales-kpis">
        <article>
          <span>Unidades vendidas</span>
          <strong>{numero(resumen.despachadas)}</strong>
          <small>despachadas confirmadas</small>
        </article>

        <article>
          <span>Valor despachado</span>
          <strong>
            {resumen.despachadas > 0 ? moneda(resumen.valor) : "—"}
          </strong>
          <small>
            {resumen.lineasSinPrecio === 0
              ? "100% valorizado"
              : `${porcentaje(resumen.coberturaPrecio)} de líneas valorizadas`}
          </small>
        </article>

        <article>
          <span>Fill Rate</span>
          <strong>{porcentaje(resumen.fillRate)}</strong>
          <small>
            {numero(resumen.despachadas)} / {numero(resumen.solicitadas)} Unid.
          </small>
        </article>

        <article>
          <span>Despachos</span>
          <strong>{numero(resumen.despachos)}</strong>
          <small>pedidos cerrados en el filtro</small>
        </article>
      </section>

      <section className="sales-shortcuts">
        <button type="button" onClick={() => cambiarPantalla("Comercial · Pedidos")}>
          Pedidos
        </button>
        <button
          type="button"
          onClick={() => cambiarPantalla("Comercial · Devoluciones")}
        >
          Devoluciones
        </button>
        <button type="button" onClick={() => cambiarPantalla("Comercial · Análisis")}>
          Análisis
        </button>
      </section>

      <nav className="sales-tabs" aria-label="Vista de ventas">
        <button
          type="button"
          className={vista === "DETALLE" ? "active" : ""}
          onClick={() => setVista("DETALLE")}
        >
          Detalle
        </button>
        <button
          type="button"
          className={vista === "CLIENTE" ? "active" : ""}
          onClick={() => setVista("CLIENTE")}
        >
          Por cliente
        </button>
        <button
          type="button"
          className={vista === "SKU" ? "active" : ""}
          onClick={() => setVista("SKU")}
        >
          Por SKU
        </button>
      </nav>

      {cargando ? (
        <div className="sales-empty">Cargando ventas...</div>
      ) : lineasFiltradas.length === 0 ? (
        <div className="sales-empty">
          No existen despachos confirmados para los filtros seleccionados.
        </div>
      ) : vista === "DETALLE" ? (
        <DetalleVentas lineas={lineasFiltradas} />
      ) : (
        <ResumenAgrupado
          filas={vista === "CLIENTE" ? resumenClientes : resumenSku}
          titulo={vista === "CLIENTE" ? "Cliente" : "SKU"}
        />
      )}

      <footer className="sales-footer">
        <strong>Criterio actual:</strong> una venta operativa nace cuando el
        pedido queda DESPACHADO. El valor usa el precio vigente configurado para
        Cliente + SKU. Cuando conectemos la facturación importada, ese valor
        contable sustituirá la valorización estimada sin cambiar el detalle
        operativo de unidades.
      </footer>
    </main>
  )
}

function DetalleVentas({ lineas }: { lineas: VentaLinea[] }) {
  return (
    <section className="sales-panel">
      <div className="sales-panel-head">
        <div>
          <span>TRANSACCIONES</span>
          <h2>Detalle de ventas</h2>
        </div>
        <small>{numero(lineas.length)} líneas</small>
      </div>

      <div className="sales-table-wrap">
        <table>
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Pedido</th>
              <th>Cliente / bodega</th>
              <th>SKU</th>
              <th>Solicitadas</th>
              <th>Despachadas</th>
              <th>Fill Rate</th>
              <th>Precio</th>
              <th>Valor</th>
            </tr>
          </thead>
          <tbody>
            {lineas.map((linea) => {
              const fill =
                linea.solicitadas > 0
                  ? (linea.despachadas / linea.solicitadas) * 100
                  : 0

              return (
                <tr key={linea.id}>
                  <td data-label="Fecha">{linea.fecha}</td>
                  <td data-label="Pedido">
                    <strong>{linea.numeroPedido}</strong>
                  </td>
                  <td data-label="Cliente / bodega">
                    <strong>{linea.cliente}</strong>
                    <small>{linea.bodega}</small>
                  </td>
                  <td data-label="SKU">
                    <strong>{linea.sku}</strong>
                    <small>{linea.codigo}</small>
                  </td>
                  <td data-label="Solicitadas">{numero(linea.solicitadas)}</td>
                  <td data-label="Despachadas">
                    <strong>{numero(linea.despachadas)}</strong>
                  </td>
                  <td data-label="Fill Rate">
                    <span className={fill >= 98 ? "good" : fill >= 95 ? "warn" : "bad"}>
                      {porcentaje(fill)}
                    </span>
                  </td>
                  <td data-label="Precio">
                    {linea.precioUnitario === null
                      ? "—"
                      : moneda(linea.precioUnitario)}
                  </td>
                  <td data-label="Valor">
                    {linea.valor === null ? "—" : <strong>{moneda(linea.valor)}</strong>}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </section>
  )
}

function ResumenAgrupado({
  filas,
  titulo,
}: {
  filas: GrupoVenta[]
  titulo: string
}) {
  return (
    <section className="sales-panel">
      <div className="sales-panel-head">
        <div>
          <span>CONSOLIDADO</span>
          <h2>Ventas por {titulo.toLowerCase()}</h2>
        </div>
        <small>{numero(filas.length)} registros</small>
      </div>

      <div className="sales-table-wrap">
        <table>
          <thead>
            <tr>
              <th>{titulo}</th>
              <th>Despachos</th>
              <th>Solicitadas</th>
              <th>Vendidas</th>
              <th>Fill Rate</th>
              <th>Valor despachado</th>
              <th>Precio pendiente</th>
            </tr>
          </thead>
          <tbody>
            {filas.map((fila) => (
              <tr key={fila.id}>
                <td data-label={titulo}>
                  <strong>{fila.nombre}</strong>
                  <small>{fila.secundario}</small>
                </td>
                <td data-label="Despachos">{numero(fila.despachos)}</td>
                <td data-label="Solicitadas">{numero(fila.solicitadas)}</td>
                <td data-label="Vendidas">
                  <strong>{numero(fila.despachadas)}</strong>
                </td>
                <td data-label="Fill Rate">
                  <span
                    className={
                      fila.fillRate >= 98
                        ? "good"
                        : fila.fillRate >= 95
                          ? "warn"
                          : "bad"
                    }
                  >
                    {porcentaje(fila.fillRate)}
                  </span>
                </td>
                <td data-label="Valor despachado">
                  <strong>{moneda(fila.valor)}</strong>
                </td>
                <td data-label="Precio pendiente">
                  {fila.lineasSinPrecio === 0 ? (
                    <span className="ready">Completo</span>
                  ) : (
                    <span className="pending">
                      {fila.lineasSinPrecio} línea
                      {fila.lineasSinPrecio === 1 ? "" : "s"}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

const css = `
  .sales-page {
    max-width: 1580px;
    margin: 0 auto;
    padding: 26px 28px 46px;
    color: #332824;
    font-variant-numeric: tabular-nums;
  }

  .sales-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 14px;
  }

  .sales-kicker,
  .sales-panel-head span {
    color: ${NARANJA};
    font-size: 10px;
    font-weight: 950;
    letter-spacing: 1.2px;
  }

  .sales-header h1 {
    margin: 4px 0 4px;
    color: ${VINO};
    font-size: clamp(28px, 3vw, 38px);
  }

  .sales-header p {
    margin: 0;
    color: #786b66;
    font-size: 13px;
  }

  .sales-header-actions {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 8px;
  }

  .sales-header-actions button,
  .sales-filter-actions button,
  .sales-shortcuts button,
  .sales-tabs button {
    min-height: 40px;
    padding: 0 14px;
    border-radius: 8px;
    font-weight: 850;
    cursor: pointer;
  }

  .sales-header-actions button:disabled {
    opacity: .55;
    cursor: wait;
  }

  .sales-header-actions .primary,
  .sales-filter-actions .apply {
    border: 1px solid ${VINO};
    background: ${VINO};
    color: white;
  }

  .sales-header-actions .secondary,
  .sales-filter-actions button,
  .sales-shortcuts button {
    border: 1px solid #dfd4ce;
    background: white;
    color: ${VINO};
  }

  .sales-source-note {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 14px;
    padding: 10px 13px;
    border: 1px solid #e4dad5;
    border-left: 4px solid ${NARANJA};
    border-radius: 8px;
    background: #fffaf6;
    color: #756863;
    font-size: 10px;
  }

  .sales-source-note strong {
    color: #54312f;
  }

  .sales-error,
  .sales-warning {
    margin-bottom: 14px;
    padding: 12px 14px;
    border-radius: 7px;
    font-size: 11px;
    line-height: 1.5;
  }

  .sales-error {
    border-left: 4px solid #c73636;
    background: #fff0f0;
    color: #9f2525;
  }

  .sales-warning {
    border-left: 4px solid #d99a28;
    background: #fff8e8;
    color: #805f1f;
  }

  .sales-warning small {
    color: #9b7b3b;
  }

  .sales-filter-panel {
    margin-bottom: 15px;
    padding: 15px;
    border: 1px solid #e7ddd7;
    border-radius: 10px;
    background: white;
    box-shadow: 0 4px 15px rgba(70, 43, 34, .04);
  }

  .sales-filter-grid {
    display: grid;
    grid-template-columns: 150px 150px minmax(190px, 1fr) minmax(210px, 1.1fr) minmax(220px, 1.2fr);
    gap: 10px;
  }

  .sales-filter-grid label {
    min-width: 0;
  }

  .sales-filter-grid label > span {
    display: block;
    margin-bottom: 5px;
    color: #7d6f69;
    font-size: 9px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .45px;
  }

  .sales-filter-grid input,
  .sales-filter-grid select {
    width: 100%;
    min-height: 39px;
    box-sizing: border-box;
    padding: 0 10px;
    border: 1px solid #dcd2cc;
    border-radius: 7px;
    background: white;
    color: #433734;
  }

  .sales-filter-grid input:focus,
  .sales-filter-grid select:focus {
    outline: 2px solid rgba(247, 147, 30, .18);
    border-color: ${NARANJA};
  }

  .sales-filter-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 11px;
  }

  .sales-kpis {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 11px;
    margin-bottom: 13px;
  }

  .sales-kpis article {
    min-width: 0;
    padding: 15px 16px;
    border: 1px solid #e8dfda;
    border-top: 3px solid ${NARANJA};
    border-radius: 9px;
    background: linear-gradient(145deg, #fffaf7, #fff);
    box-shadow: 0 4px 14px rgba(70, 43, 34, .04);
  }

  .sales-kpis span {
    display: block;
    color: #796b65;
    font-size: 9px;
    font-weight: 950;
    letter-spacing: .45px;
    text-transform: uppercase;
  }

  .sales-kpis strong {
    display: block;
    margin: 6px 0 3px;
    color: ${VINO};
    font-size: 25px;
    line-height: 1.05;
  }

  .sales-kpis small {
    color: #9a8c86;
    font-size: 9px;
  }

  .sales-shortcuts {
    display: flex;
    gap: 7px;
    margin-bottom: 15px;
  }

  .sales-shortcuts button {
    min-height: 34px;
    padding: 0 11px;
    font-size: 10px;
  }

  .sales-tabs {
    display: flex;
    gap: 4px;
    width: fit-content;
    max-width: 100%;
    margin-bottom: 12px;
    padding: 4px;
    border-radius: 9px;
    background: #f1ebe7;
    overflow-x: auto;
  }

  .sales-tabs button {
    min-height: 36px;
    border: 0;
    background: transparent;
    color: #796b65;
    font-size: 10px;
  }

  .sales-tabs button.active {
    background: white;
    color: ${VINO};
    box-shadow: 0 2px 8px rgba(72, 45, 36, .1);
  }

  .sales-panel {
    border: 1px solid #e5dcd7;
    border-radius: 10px;
    background: white;
    box-shadow: 0 5px 18px rgba(62, 40, 33, .045);
    overflow: hidden;
  }

  .sales-panel-head {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 12px;
    padding: 16px 17px 12px;
    border-bottom: 1px solid #eee6e1;
  }

  .sales-panel-head h2 {
    margin: 3px 0 0;
    color: #4f2b2b;
    font-size: 19px;
  }

  .sales-panel-head small {
    color: #9b8d87;
    font-size: 10px;
  }

  .sales-table-wrap {
    width: 100%;
    overflow-x: auto;
  }

  .sales-table-wrap table {
    width: 100%;
    min-width: 1040px;
    border-collapse: collapse;
  }

  .sales-table-wrap th {
    padding: 10px 10px;
    border-bottom: 2px solid #e9dfda;
    background: #fcfaf8;
    color: #887a74;
    font-size: 8px;
    font-weight: 950;
    letter-spacing: .4px;
    text-align: right;
    text-transform: uppercase;
  }

  .sales-table-wrap th:nth-child(-n+4) {
    text-align: left;
  }

  .sales-table-wrap td {
    padding: 11px 10px;
    border-bottom: 1px solid #f0e9e5;
    color: #514641;
    font-size: 10px;
    text-align: right;
    vertical-align: middle;
  }

  .sales-table-wrap td:nth-child(-n+4) {
    text-align: left;
  }

  .sales-table-wrap td strong {
    color: #4f2e2e;
  }

  .sales-table-wrap td small {
    display: block;
    margin-top: 2px;
    color: #9c8e88;
    font-size: 8px;
  }

  .sales-table-wrap tbody tr:hover {
    background: #fffbf8;
  }

  .good,
  .warn,
  .bad,
  .ready,
  .pending {
    display: inline-flex;
    padding: 4px 7px;
    border-radius: 999px;
    font-size: 9px;
    font-weight: 900;
    white-space: nowrap;
  }

  .good,
  .ready {
    background: #e8f7ed;
    color: #087b35;
  }

  .warn,
  .pending {
    background: #fff4dc;
    color: #956512;
  }

  .bad {
    background: #fff0f0;
    color: #b62b2b;
  }

  .sales-empty {
    padding: 48px 20px;
    border: 1px dashed #d8ccc5;
    border-radius: 10px;
    background: #fff;
    color: #8e817b;
    text-align: center;
  }

  .sales-footer {
    margin-top: 14px;
    padding: 12px 14px;
    border-radius: 8px;
    background: #f7f3f0;
    color: #7b6d67;
    font-size: 9px;
    line-height: 1.5;
  }

  @media (max-width: 1180px) {
    .sales-filter-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .sales-search {
      grid-column: 1 / -1;
    }

    .sales-kpis {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 720px) {
    .sales-page {
      padding: 18px 12px 34px;
    }

    .sales-header {
      flex-direction: column;
    }

    .sales-header-actions {
      width: 100%;
      justify-content: stretch;
    }

    .sales-header-actions button {
      flex: 1;
    }

    .sales-source-note {
      align-items: flex-start;
      flex-direction: column;
    }

    .sales-filter-grid {
      grid-template-columns: 1fr;
    }

    .sales-search {
      grid-column: auto;
    }

    .sales-filter-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
    }

    .sales-kpis {
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }

    .sales-kpis article {
      padding: 12px;
    }

    .sales-kpis strong {
      font-size: 21px;
    }

    .sales-shortcuts {
      overflow-x: auto;
    }

    .sales-table-wrap {
      overflow: visible;
    }

    .sales-table-wrap table,
    .sales-table-wrap thead,
    .sales-table-wrap tbody,
    .sales-table-wrap tr,
    .sales-table-wrap td {
      display: block;
      width: 100%;
      min-width: 0;
      box-sizing: border-box;
    }

    .sales-table-wrap thead {
      display: none;
    }

    .sales-table-wrap tbody {
      padding: 8px;
    }

    .sales-table-wrap tr {
      margin-bottom: 8px;
      padding: 8px 10px;
      border: 1px solid #ece3de;
      border-radius: 8px;
    }

    .sales-table-wrap td,
    .sales-table-wrap td:nth-child(-n+4) {
      display: grid;
      grid-template-columns: minmax(100px, .75fr) minmax(0, 1.25fr);
      gap: 10px;
      padding: 6px 0;
      border-bottom: 1px solid #f2ece8;
      text-align: right;
    }

    .sales-table-wrap td:last-child {
      border-bottom: 0;
    }

    .sales-table-wrap td::before {
      content: attr(data-label);
      color: #8a7d77;
      font-size: 8px;
      font-weight: 950;
      text-align: left;
      text-transform: uppercase;
    }
  }

  @media print {
    .sales-header-actions,
    .sales-filter-panel,
    .sales-shortcuts,
    .sales-tabs {
      display: none !important;
    }

    .sales-page {
      max-width: none;
      padding: 0;
    }

    .sales-panel {
      box-shadow: none;
    }
  }
`
