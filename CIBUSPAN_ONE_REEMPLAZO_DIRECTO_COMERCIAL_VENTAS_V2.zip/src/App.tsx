import { useEffect, useState } from "react"
import type { Session } from "@supabase/supabase-js"

import { supabase } from "./lib/supabase"

import Layout from "./components/layout/Layout"
import Login from "./pages/Login"
import DashboardV2 from "./pages/DashboardV2"
import PedidosV2 from "./pages/PedidosV2"
import InventarioV2 from "./pages/InventarioV2"
import ProduccionV2 from "./pages/ProduccionV2"
import DespachosV2 from "./pages/DespachosV2"
import HistorialDespachos from "./pages/HistorialDespachos"
import Devoluciones from "./pages/Devoluciones"
import Reportes from "./pages/Reportes"
import Documentos from "./pages/Documentos"
import AnexoSupermaxi from "./pages/AnexoSupermaxi.tsx"
import ImprimirAnexoSupermaxi from "./pages/ImprimirAnexoSupermaxi"
import Administracion from "./pages/Administracion"
import HojaProduccion from "./pages/HojaProduccion"
import HojaDespacho from "./pages/HojaDespacho"
import EtiquetadoSemielaborados from "./pages/EtiquetadoSemielaborados"
import MateriasPrimas from "./pages/MateriasPrimas"
import Preformulacion from "./pages/Preformulacion"
import ComercialResumen from "./pages/ComercialResumen"
import ComercialVentas from "./pages/ComercialVentas"

function PantallaEnConstruccion({
  titulo,
  detalle,
}: {
  titulo: string
  detalle?: string
}) {
  return (
    <section
      style={{
        padding: "28px",
        maxWidth: "1180px",
        margin: "0 auto",
      }}
    >
      <div
        style={{
          border: "1px solid #eadfd8",
          borderRadius: "16px",
          background: "white",
          padding: "24px",
          boxShadow: "0 8px 28px rgba(73, 45, 35, 0.06)",
        }}
      >
        <p
          style={{
            margin: "0 0 6px",
            color: "#F7931E",
            fontSize: "12px",
            fontWeight: 800,
            textTransform: "uppercase",
            letterSpacing: ".04em",
          }}
        >
          CIBUSPAN ONE · Navegación V2
        </p>
        <h1 style={{ margin: "0 0 10px", color: "#8F1D24" }}>{titulo}</h1>
        <p style={{ margin: 0, color: "#6b625f", lineHeight: 1.55 }}>
          {detalle ??
            "La ubicación ya quedó creada dentro de la nueva arquitectura. La función se integrará en las siguientes fases sin afectar los módulos actuales."}
        </p>
      </div>
    </section>
  )
}

function App() {
  const [sesion, setSesion] = useState<Session | null>(null)
  const [cargandoSesion, setCargandoSesion] = useState(true)
  const [pantalla, setPantalla] = useState("Dashboard")

  const parametros = new URLSearchParams(window.location.search)
  const modo = parametros.get("modo")

  useEffect(() => {
    async function revisarSesion() {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      setSesion(session)
      setCargandoSesion(false)
    }

    revisarSesion()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_evento, session) => {
      setSesion(session)
      setCargandoSesion(false)
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  async function cerrarSesion() {
    await supabase.auth.signOut({
      scope: "local",
    })

    setPantalla("Dashboard")
  }

  if (cargandoSesion) {
    return (
      <main style={paginaCarga}>
        <div style={cargador}>
          <div style={iconoCarga}>C1</div>

          <h1 style={{ margin: 0 }}>CIBUSPAN ONE</h1>

          <p
            style={{
              margin: 0,
              color: "#6b7280",
            }}
          >
            Verificando sesión...
          </p>
        </div>
      </main>
    )
  }

  if (!sesion) {
    return <Login />
  }

  if (modo === "imprimir-anexo-supermaxi") {
    return <ImprimirAnexoSupermaxi />
  }

  function renderPantalla() {
    switch (pantalla) {
      // ---------------------------------------------------------
      // INICIO
      // ---------------------------------------------------------
      case "Dashboard":
        return <DashboardV2 />

      // ---------------------------------------------------------
      // COMERCIAL
      // ---------------------------------------------------------
      case "Comercial · Pedidos":
      case "Pedidos":
        return <PedidosV2 />

      case "Comercial · Devoluciones":
      case "Devoluciones":
        return <Devoluciones />

      case "Comercial · Análisis":
        return <Reportes />

      case "Comercial · Resumen":
        return <ComercialResumen cambiarPantalla={setPantalla} />

      case "Comercial · Ventas":
        return <ComercialVentas cambiarPantalla={setPantalla} />

      case "Comercial · Clientes":
      case "Comercial · SKU":
        return <PantallaEnConstruccion titulo={pantalla} />

      // ---------------------------------------------------------
      // PRODUCCIÓN
      // ---------------------------------------------------------
      case "Producción · Producción":
      case "Producción":
        return <ProduccionV2 />

      case "Producción · Fórmulas":
      case "Preformulación":
        return <Preformulacion />

      case "Producción · Etiquetado":
      case "Semielaborados":
        return <EtiquetadoSemielaborados />

      case "Hoja de producción":
        return <HojaProduccion />

      case "Producción · Análisis":
        return <Reportes />

      case "Producción · Resumen":
      case "Producción · Planificación":
      case "Producción · Semielaborados":
      case "Producción · Historial":
        return <PantallaEnConstruccion titulo={pantalla} />

      // ---------------------------------------------------------
      // INVENTARIO Y DESPACHOS
      // ---------------------------------------------------------
      case "Inventario y Despachos · Inventario":
      case "Inventario":
        return <InventarioV2 />

      case "Inventario y Despachos · Despachos":
      case "Despachos":
        return <DespachosV2 />

      case "Inventario y Despachos · Historial":
      case "Historial despachos":
        return <HistorialDespachos />

      case "Inventario y Despachos · Documentos":
      case "Documentos":
        return <Documentos cambiarPantalla={setPantalla} />

      case "Hoja de despacho":
        return <HojaDespacho />

      case "Anexo Supermaxi":
        return <AnexoSupermaxi />

      case "Inventario y Despachos · Análisis":
        return <Reportes />

      case "Inventario y Despachos · Resumen":
      case "Inventario y Despachos · Preparación":
        return <PantallaEnConstruccion titulo={pantalla} />

      // ---------------------------------------------------------
      // COMPRAS
      // ---------------------------------------------------------
      case "Compras · Materias Primas y Empaques":
      case "Materias primas":
        return <MateriasPrimas />

      case "Compras · Resumen":
      case "Compras · Proveedores":
      case "Compras · Facturas":
      case "Compras · Costos":
      case "Compras · Historial":
      case "Compras · Análisis":
        return <PantallaEnConstruccion titulo={pantalla} />

      // ---------------------------------------------------------
      // PAGOS Y FINANZAS
      // ---------------------------------------------------------
      case "Pagos y Finanzas · Resumen":
      case "Pagos y Finanzas · Resultados":
      case "Pagos y Finanzas · Rentabilidad":
      case "Pagos y Finanzas · Análisis":
      case "Reportes":
        return <Reportes />

      case "Pagos y Finanzas · Cuentas por Cobrar":
      case "Pagos y Finanzas · Cobros y Conciliación":
      case "Pagos y Finanzas · Cuentas por Pagar":
      case "Pagos y Finanzas · Pagos":
      case "Pagos y Finanzas · Tesorería":
      case "Pagos y Finanzas · Historial":
        return <PantallaEnConstruccion titulo={pantalla} />

      // ---------------------------------------------------------
      // ADMINISTRACIÓN
      // ---------------------------------------------------------
      case "Administración · Resumen":
      case "Administración · Usuarios y Permisos":
      case "Administración":
        return <Administracion cambiarPantalla={setPantalla} />

      case "Administración · Maestros":
      case "Administración · Configuración":
      case "Administración · Importaciones":
      case "Administración · Auditoría":
      case "Administración · Sistema":
        return <PantallaEnConstruccion titulo={pantalla} />

      default:
        return <PantallaEnConstruccion titulo={pantalla} />
    }
  }

  return (
    <Layout
      pantalla={pantalla}
      cambiarPantalla={setPantalla}
      cerrarSesion={cerrarSesion}
      usuario={sesion.user.email}
    >
      {renderPantalla()}
    </Layout>
  )
}

const paginaCarga = {
  minHeight: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "24px",
  background: "#f8f5f1",
}

const cargador = {
  display: "flex",
  flexDirection: "column" as const,
  alignItems: "center",
  gap: "14px",
}

const iconoCarga = {
  width: "58px",
  height: "58px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "14px",
  background: "#8F1D24",
  color: "white",
  fontWeight: "bold",
  fontSize: "20px",
}

export default App
